define({
	root : ({
		"acctDashboard":"My accounts",
		"wlcmBack":"Welcome back",
		"wlcm":"Welcome",
		"datePattern" : "dd/MM/yyyy" ,
		"lastLggdIn":" you last logged in at",
		"comma" : ",",
		"gmt":"GMT",
		"on":"on",
		"balanceMsg":"Balances as at ",
		"utc":"UTC",
		"onn":"on",
		"unlsStdMsg":"(unless stated)",
		"ncontent": "${time} ${timeZone} on ${date}"
	}),
	"es-ar": true,
	"hi-in": true,
	"ar-sa": true,
	"en-ph": true,
	"en-je": true,
	"ar-ae": true,
	"pt-br": true,
	"zh-hk": true,
	"zh-cn": true,
	"en-hk": true
});
