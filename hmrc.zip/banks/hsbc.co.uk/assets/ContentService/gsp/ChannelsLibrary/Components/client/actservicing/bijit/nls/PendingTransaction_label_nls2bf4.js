define({
	root : ({
		pendingTxnHeading : "You have pending transaction.",
		date : "Date",
		description : "Description",
		amount : "Amount",
		detailDescription : "These transactions are due to be processed within the next working day, but have not yet happened. Note that <b>pending card payments will not appear here.</b>",
		footerDescription : "Pending transactions may still be cancelled or returned. They are not guaranteed to be paid or to appear on your statement.",
		totalPending : "Total Pending",
		pendingDialogHeading : "Pending transactions",
		pendingTxnLink: "View pending transactions",
		moreOfPendingTxn : "More about pending transactions",
		lessOfPendingTxn : "Less about pending transactions",
		bigLorem1: "Pending transactions shown here may include:<br><br>- Uncleared cheques<br>- BACS payments<br>- Direct Debits<br>- Transactions made outside working hours",
		bigLorem2: "Transactions that will not be shown here include:<br><br>- Standing orders<br>- Faster Payments transfers<br>- Scheduled future payments<br><br>To check or cancel future payments, bill payments or other transactions, select <b>Move money</b>.",
		close : "Close"
	})
});