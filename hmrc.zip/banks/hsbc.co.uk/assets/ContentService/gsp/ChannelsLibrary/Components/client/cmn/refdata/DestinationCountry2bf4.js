define(({
	"DestinationCountry": [{
		"id": 'AD',
		"desckey": 'AD',
		"defaultflag": 'N'
	},
	{
		"id": 'AE',
		"desckey": 'AE',
		"defaultflag": 'N'
	},
	{
		"id": 'AF',
		"desckey": 'AF',
		"defaultflag": 'N'
	},
	{
		"id": 'AG',
		"desckey": 'AG',
		"defaultflag": 'N'
	},
	{
		"id": 'AI',
		"desckey": 'AI',
		"defaultflag": 'N'
	},
	{
		"id": 'AL',
		"desckey": 'AL',
		"defaultflag": 'N'
	},
	{
		"id": 'AM',
		"desckey": 'AM',
		"defaultflag": 'N'
	},
	{
		"id": 'AO',
		"desckey": 'AO',
		"defaultflag": 'N'
	},
	{
		"id": 'AQ',
		"desckey": 'AQ',
		"defaultflag": 'N'
	},
	{
		"id": 'AR',
		"desckey": 'AR',
		"defaultflag": 'N'
	},
	{
		"id": 'AS',
		"desckey": 'AS',
		"defaultflag": 'N'
	},
	{
		"id": 'AT',
		"desckey": 'AT',
		"defaultflag": 'N'
	},
	{
		"id": 'AU',
		"desckey": 'AU',
		"defaultflag": 'N'
	},
	{
		"id": 'AW',
		"desckey": 'AW',
		"defaultflag": 'N'
	},
	{
		"id": 'AX',
		"desckey": 'AX',
		"defaultflag": 'N'
	},
	{
		"id": 'AZ',
		"desckey": 'AZ',
		"defaultflag": 'N'
	},
	{
		"id": 'BA',
		"desckey": 'BA',
		"defaultflag": 'N'
	},
	{
		"id": 'BB',
		"desckey": 'BB',
		"defaultflag": 'N'
	},
	{
		"id": 'BD',
		"desckey": 'BD',
		"defaultflag": 'N'
	},
	{
		"id": 'BE',
		"desckey": 'BE',
		"defaultflag": 'N'
	},
	{
		"id": 'BF',
		"desckey": 'BF',
		"defaultflag": 'N'
	},
	{
		"id": 'BG',
		"desckey": 'BG',
		"defaultflag": 'N'
	},
	{
		"id": 'BH',
		"desckey": 'BH',
		"defaultflag": 'N'
	},
	{
		"id": 'BI',
		"desckey": 'BI',
		"defaultflag": 'N'
	},
	{
		"id": 'BJ',
		"desckey": 'BJ',
		"defaultflag": 'N'
	},
	{
		"id": 'BL',
		"desckey": 'BL',
		"defaultflag": 'N'
	},
	{
		"id": 'BM',
		"desckey": 'BM',
		"defaultflag": 'N'
	},
	{
		"id": 'BN',
		"desckey": 'BN',
		"defaultflag": 'N'
	},
	{
		"id": 'BO',
		"desckey": 'BO',
		"defaultflag": 'N'
	},
	{
		"id": 'BR',
		"desckey": 'BR',
		"defaultflag": 'N'
	},
	{
		"id": 'BS',
		"desckey": 'BS',
		"defaultflag": 'N'
	},
	{
		"id": 'BT',
		"desckey": 'BT',
		"defaultflag": 'N'
	},
	{
		"id": 'BQ',
		"desckey": 'BQ',
		"defaultflag": 'N'
	},
	{
		"id": 'BV',
		"desckey": 'BV',
		"defaultflag": 'N'
	},
	{
		"id": 'BW',
		"desckey": 'BW',
		"defaultflag": 'N'
	},
	{
		"id": 'BY',
		"desckey": 'BY',
		"defaultflag": 'N'
	},
	{
		"id": 'BZ',
		"desckey": 'BZ',
		"defaultflag": 'N'
	},
	{
		"id": 'CA',
		"desckey": 'CA',
		"defaultflag": 'N'
	},
	{
		"id": 'CC',
		"desckey": 'CC',
		"defaultflag": 'N'
	},
	{
		"id": 'CD',
		"desckey": 'CD',
		"defaultflag": 'N'
	},
	{
		"id": 'CF',
		"desckey": 'CF',
		"defaultflag": 'N'
	},
	{
		"id": 'CG',
		"desckey": 'CG',
		"defaultflag": 'N'
	},
	{
		"id": 'CH',
		"desckey": 'CH',
		"defaultflag": 'N'
	},
	{
		"id": 'CI',
		"desckey": 'CI',
		"defaultflag": 'N'
	},
	{
		"id": 'CK',
		"desckey": 'CK',
		"defaultflag": 'N'
	},
	{
		"id": 'CL',
		"desckey": 'CL',
		"defaultflag": 'N'
	},
	{
		"id": 'CM',
		"desckey": 'CM',
		"defaultflag": 'N'
	},
	{
		"id": 'CN',
		"desckey": 'CN',
		"defaultflag": 'N'
	},
	{
		"id": 'CU',
		"desckey": 'CU',
		"defaultflag": 'N'
	},
	{
		"id": 'CO',
		"desckey": 'CO',
		"defaultflag": 'N'
	},
	{
		"id": 'CR',
		"desckey": 'CR',
		"defaultflag": 'N'
	},
	{
		"id": 'CV',
		"desckey": 'CV',
		"defaultflag": 'N'
	},
	{
		"id": 'CW',
		"desckey": 'CW',
		"defaultflag": 'N'
	},
	{
		"id": 'CX',
		"desckey": 'CX',
		"defaultflag": 'N'
	},
	{
		"id": 'CY',
		"desckey": 'CY',
		"defaultflag": 'N'
	},
	{
		"id": 'CZ',
		"desckey": 'CZ',
		"defaultflag": 'N'
	},
	{
		"id": 'DE',
		"desckey": 'DE',
		"defaultflag": 'N'
	},
	{
		"id": 'DJ',
		"desckey": 'DJ',
		"defaultflag": 'N'
	},
	{
		"id": 'DK',
		"desckey": 'DK',
		"defaultflag": 'N'
	},
	{
		"id": 'DM',
		"desckey": 'DM',
		"defaultflag": 'N'
	},
	{
		"id": 'DO',
		"desckey": 'DO',
		"defaultflag": 'N'
	},
	{
		"id": 'DZ',
		"desckey": 'DZ',
		"defaultflag": 'N'
	},
	{
		"id": 'EC',
		"desckey": 'EC',
		"defaultflag": 'N'
	},
	{
		"id": 'EE',
		"desckey": 'EE',
		"defaultflag": 'N'
	},
	{
		"id": 'EG',
		"desckey": 'EG',
		"defaultflag": 'N'
	},
	{
		"id": 'EH',
		"desckey": 'EH',
		"defaultflag": 'N'
	},
	{
		"id": 'ER',
		"desckey": 'ER',
		"defaultflag": 'N'
	},
	{
		"id": 'ES',
		"desckey": 'ES',
		"defaultflag": 'N'
	},
	{
		"id": 'ET',
		"desckey": 'ET',
		"defaultflag": 'N'
	},
	{
		"id": 'FI',
		"desckey": 'FI',
		"defaultflag": 'N'
	},
	{
		"id": 'FJ',
		"desckey": 'FJ',
		"defaultflag": 'N'
	},
	{
		"id": 'FK',
		"desckey": 'FK',
		"defaultflag": 'N'
	},
	{
		"id": 'FM',
		"desckey": 'FM',
		"defaultflag": 'N'
	},
	{
		"id": 'FO',
		"desckey": 'FO',
		"defaultflag": 'N'
	},
	{
		"id": 'FR',
		"desckey": 'FR',
		"defaultflag": 'N'
	},
	{
		"id": 'GA',
		"desckey": 'GA',
		"defaultflag": 'N'
	},
	{
		"id": 'GB',
		"desckey": 'GB',
		"defaultflag": 'Y'
	},
	{
		"id": 'GD',
		"desckey": 'GD',
		"defaultflag": 'N'
	},
	{
		"id": 'GE',
		"desckey": 'GE',
		"defaultflag": 'N'
	},
	{
		"id": 'GF',
		"desckey": 'GF',
		"defaultflag": 'N'
	},
	{
		"id": 'GG',
		"desckey": 'GG',
		"defaultflag": 'N'
	},
	{
		"id": 'GH',
		"desckey": 'GH',
		"defaultflag": 'N'
	},
	{
		"id": 'GI',
		"desckey": 'GI',
		"defaultflag": 'N'
	},
	{
		"id": 'GL',
		"desckey": 'GL',
		"defaultflag": 'N'
	},
	{
		"id": 'GM',
		"desckey": 'GM',
		"defaultflag": 'N'
	},
	{
		"id": 'GN',
		"desckey": 'GN',
		"defaultflag": 'N'
	},
	{
		"id": 'GP',
		"desckey": 'GP',
		"defaultflag": 'N'
	},
	{
		"id": 'GQ',
		"desckey": 'GQ',
		"defaultflag": 'N'
	},
	{
		"id": 'GR',
		"desckey": 'GR',
		"defaultflag": 'N'
	},
	{
		"id": 'GS',
		"desckey": 'GS',
		"defaultflag": 'N'
	},
	{
		"id": 'GT',
		"desckey": 'GT',
		"defaultflag": 'N'
	},
	{
		"id": 'GU',
		"desckey": 'GU',
		"defaultflag": 'N'
	},
	{
		"id": 'GW',
		"desckey": 'GW',
		"defaultflag": 'N'
	},
	{
		"id": 'GY',
		"desckey": 'GY',
		"defaultflag": 'N'
	},
	{
		"id": 'HK',
		"desckey": 'HK',
		"defaultflag": 'N'
	},
	{
		"id": 'HM',
		"desckey": 'HM',
		"defaultflag": 'N'
	},
	{
		"id": 'HN',
		"desckey": 'HN',
		"defaultflag": 'N'
	},
	{
		"id": 'HT',
		"desckey": 'HT',
		"defaultflag": 'N'
	},
	{
		"id": 'HU',
		"desckey": 'HU',
		"defaultflag": 'N'
	},
	{
		"id": 'HR',
		"desckey": 'HR',
		"defaultflag": 'N'
	},
	{
		"id": 'ID',
		"desckey": 'ID',
		"defaultflag": 'N'
	},
	{
		"id": 'IE',
		"desckey": 'IE',
		"defaultflag": 'N'
	},
	{
		"id": 'IL',
		"desckey": 'IL',
		"defaultflag": 'N'
	},
	{
		"id": 'IM',
		"desckey": 'IM',
		"defaultflag": 'N'
	},
	{
		"id": 'IN',
		"desckey": 'IN',
		"defaultflag": 'N'
	},
	{
		"id": 'IO',
		"desckey": 'IO',
		"defaultflag": 'N'
	},
	{
		"id": 'IQ',
		"desckey": 'IQ',
		"defaultflag": 'N'
	},
	{
		"id": 'IS',
		"desckey": 'IS',
		"defaultflag": 'N'
	},
	{
		"id": 'IT',
		"desckey": 'IT',
		"defaultflag": 'N'
	},
	{
		"id": 'JE',
		"desckey": 'JE',
		"defaultflag": 'N'
	},
	{
		"id": 'JM',
		"desckey": 'JM',
		"defaultflag": 'N'
	},
	{
		"id": 'JO',
		"desckey": 'JO',
		"defaultflag": 'N'
	},
	{
		"id": 'JP',
		"desckey": 'JP',
		"defaultflag": 'N'
	},
	{
		"id": 'KE',
		"desckey": 'KE',
		"defaultflag": 'N'
	},
	{
		"id": 'KG',
		"desckey": 'KG',
		"defaultflag": 'N'
	},
	{
		"id": 'KH',
		"desckey": 'KH',
		"defaultflag": 'N'
	},
	{
		"id": 'KI',
		"desckey": 'KI',
		"defaultflag": 'N'
	},
	{
		"id": 'KM',
		"desckey": 'KM',
		"defaultflag": 'N'
	},
	{
		"id": 'KN',
		"desckey": 'KN',
		"defaultflag": 'N'
	},
	{
		"id": 'KR',
		"desckey": 'KR',
		"defaultflag": 'N'
	},
	{
		"id": 'KW',
		"desckey": 'KW',
		"defaultflag": 'N'
	},
	{
		"id": 'KY',
		"desckey": 'KY',
		"defaultflag": 'N'
	},
	{
		"id": 'KZ',
		"desckey": 'KZ',
		"defaultflag": 'N'
	},
	{
		"id": 'LA',
		"desckey": 'LA',
		"defaultflag": 'N'
	},
	{
		"id": 'LB',
		"desckey": 'LB',
		"defaultflag": 'N'
	},
	{
		"id": 'LC',
		"desckey": 'LC',
		"defaultflag": 'N'
	},
	{
		"id": 'LI',
		"desckey": 'LI',
		"defaultflag": 'N'
	},
	{
		"id": 'LK',
		"desckey": 'LK',
		"defaultflag": 'N'
	},
	{
		"id": 'LR',
		"desckey": 'LR',
		"defaultflag": 'N'
	},
	{
		"id": 'LS',
		"desckey": 'LS',
		"defaultflag": 'N'
	},
	{
		"id": 'LT',
		"desckey": 'LT',
		"defaultflag": 'N'
	},
	{
		"id": 'LU',
		"desckey": 'LU',
		"defaultflag": 'N'
	},
	{
		"id": 'LV',
		"desckey": 'LV',
		"defaultflag": 'N'
	},
	{
		"id": 'LY',
		"desckey": 'LY',
		"defaultflag": 'N'
	},
	{
		"id": 'MA',
		"desckey": 'MA',
		"defaultflag": 'N'
	},
	{
		"id": 'MC',
		"desckey": 'MC',
		"defaultflag": 'N'
	},
	{
		"id": 'MD',
		"desckey": 'MD',
		"defaultflag": 'N'
	},
	{
		"id": 'ME',
		"desckey": 'ME',
		"defaultflag": 'N'
	},
	{
		"id": 'MF',
		"desckey": 'MF',
		"defaultflag": 'N'
	},
	{
		"id": 'MG',
		"desckey": 'MG',
		"defaultflag": 'N'
	},
	{
		"id": 'MH',
		"desckey": 'MH',
		"defaultflag": 'N'
	},
	{
		"id": 'MM',
		"desckey": 'MM',
		"defaultflag": 'N'
	},
	{
		"id": 'MK',
		"desckey": 'MK',
		"defaultflag": 'N'
	},
	{
		"id": 'ML',
		"desckey": 'ML',
		"defaultflag": 'N'
	},
	{
		"id": 'MN',
		"desckey": 'MN',
		"defaultflag": 'N'
	},
	{
		"id": 'MO',
		"desckey": 'MO',
		"defaultflag": 'N'
	},
	{
		"id": 'MP',
		"desckey": 'MP',
		"defaultflag": 'N'
	},
	{
		"id": 'MQ',
		"desckey": 'MQ',
		"defaultflag": 'N'
	},
	{
		"id": 'MR',
		"desckey": 'MR',
		"defaultflag": 'N'
	},
	{
		"id": 'MS',
		"desckey": 'MS',
		"defaultflag": 'N'
	},
	{
		"id": 'MT',
		"desckey": 'MT',
		"defaultflag": 'N'
	},
	{
		"id": 'MU',
		"desckey": 'MU',
		"defaultflag": 'N'
	},
	{
		"id": 'MV',
		"desckey": 'MV',
		"defaultflag": 'N'
	},
	{
		"id": 'MW',
		"desckey": 'MW',
		"defaultflag": 'N'
	},
	{
		"id": 'MX',
		"desckey": 'MX',
		"defaultflag": 'N'
	},
	{
		"id": 'MY',
		"desckey": 'MY',
		"defaultflag": 'N'
	},
	{
		"id": 'MZ',
		"desckey": 'MZ',
		"defaultflag": 'N'
	},
	{
		"id": 'NA',
		"desckey": 'NA',
		"defaultflag": 'N'
	},
	{
		"id": 'NC',
		"desckey": 'NC',
		"defaultflag": 'N'
	},
	{
		"id": 'NE',
		"desckey": 'NE',
		"defaultflag": 'N'
	},
	{
		"id": 'NF',
		"desckey": 'NF',
		"defaultflag": 'N'
	},
	{
		"id": 'NG',
		"desckey": 'NG',
		"defaultflag": 'N'
	},
	{
		"id": 'NI',
		"desckey": 'NI',
		"defaultflag": 'N'
	},
	{
		"id": 'NL',
		"desckey": 'NL',
		"defaultflag": 'N'
	},
	{
		"id": 'NO',
		"desckey": 'NO',
		"defaultflag": 'N'
	},
	{
		"id": 'NP',
		"desckey": 'NP',
		"defaultflag": 'N'
	},
	{
		"id": 'NR',
		"desckey": 'NR',
		"defaultflag": 'N'
	},
	{
		"id": 'NU',
		"desckey": 'NU',
		"defaultflag": 'N'
	},
	{
		"id": 'NZ',
		"desckey": 'NZ',
		"defaultflag": 'N'
	},
	{
		"id": 'OM',
		"desckey": 'OM',
		"defaultflag": 'N'
	},
	{
		"id": 'PA',
		"desckey": 'PA',
		"defaultflag": 'N'
	},
	{
		"id": 'PE',
		"desckey": 'PE',
		"defaultflag": 'N'
	},
	{
		"id": 'PF',
		"desckey": 'PF',
		"defaultflag": 'N'
	},
	{
		"id": 'PG',
		"desckey": 'PG',
		"defaultflag": 'N'
	},
	{
		"id": 'PH',
		"desckey": 'PH',
		"defaultflag": 'N'
	},
	{
		"id": 'PK',
		"desckey": 'PK',
		"defaultflag": 'N'
	},
	{
		"id": 'PL',
		"desckey": 'PL',
		"defaultflag": 'N'
	},
	{
		"id": 'PM',
		"desckey": 'PM',
		"defaultflag": 'N'
	},
	{
		"id": 'PN',
		"desckey": 'PN',
		"defaultflag": 'N'
	},
	{
		"id": 'PR',
		"desckey": 'PR',
		"defaultflag": 'N'
	},
	{
		"id": 'PS',
		"desckey": 'PS',
		"defaultflag": 'N'
	},
	{
		"id": 'PT',
		"desckey": 'PT',
		"defaultflag": 'N'
	},
	{
		"id": 'PW',
		"desckey": 'PW',
		"defaultflag": 'N'
	},
	{
		"id": 'PY',
		"desckey": 'PY',
		"defaultflag": 'N'
	},
	{
		"id": 'QA',
		"desckey": 'QA',
		"defaultflag": 'N'
	},
	{
		"id": 'RE',
		"desckey": 'RE',
		"defaultflag": 'N'
	},
	{
		"id": 'RO',
		"desckey": 'RO',
		"defaultflag": 'N'
	},
	{
		"id": 'RS',
		"desckey": 'RS',
		"defaultflag": 'N'
	},
	{
		"id": 'RU',
		"desckey": 'RU',
		"defaultflag": 'N'
	},
	{
		"id": 'RW',
		"desckey": 'RW',
		"defaultflag": 'N'
	},
	{
		"id": 'SA',
		"desckey": 'SA',
		"defaultflag": 'N'
	},
	{
		"id": 'SB',
		"desckey": 'SB',
		"defaultflag": 'N'
	},
	{
		"id": 'SC',
		"desckey": 'SC',
		"defaultflag": 'N'
	},
	{
		"id": 'SE',
		"desckey": 'SE',
		"defaultflag": 'N'
	},
	{
		"id": 'SG',
		"desckey": 'SG',
		"defaultflag": 'N'
	},
	{
		"id": 'SH',
		"desckey": 'SH',
		"defaultflag": 'N'
	},
	{
		"id": 'SI',
		"desckey": 'SI',
		"defaultflag": 'N'
	},
	{
		"id": 'SJ',
		"desckey": 'SJ',
		"defaultflag": 'N'
	},
	{
		"id": 'SK',
		"desckey": 'SK',
		"defaultflag": 'N'
	},
	{
		"id": 'SL',
		"desckey": 'SL',
		"defaultflag": 'N'
	},
	{
		"id": 'SM',
		"desckey": 'SM',
		"defaultflag": 'N'
	},
	{
		"id": 'SN',
		"desckey": 'SN',
		"defaultflag": 'N'
	},
	{
		"id": 'SO',
		"desckey": 'SO',
		"defaultflag": 'N'
	},
	{
		"id": 'SR',
		"desckey": 'SR',
		"defaultflag": 'N'
	},
	{
		"id": 'ST',
		"desckey": 'ST',
		"defaultflag": 'N'
	},
	{
		"id": 'SV',
		"desckey": 'SV',
		"defaultflag": 'N'
	},
	{
		"id": 'SZ',
		"desckey": 'SZ',
		"defaultflag": 'N'
	},
	{
		"id": 'TC',
		"desckey": 'TC',
		"defaultflag": 'N'
	},
	{
		"id": 'TD',
		"desckey": 'TD',
		"defaultflag": 'N'
	},
	{
		"id": 'TF',
		"desckey": 'TF',
		"defaultflag": 'N'
	},
	{
		"id": 'TG',
		"desckey": 'TG',
		"defaultflag": 'N'
	},
	{
		"id": 'TH',
		"desckey": 'TH',
		"defaultflag": 'N'
	},
	{
		"id": 'TJ',
		"desckey": 'TJ',
		"defaultflag": 'N'
	},
	{
		"id": 'TK',
		"desckey": 'TK',
		"defaultflag": 'N'
	},
	{
		"id": 'TL',
		"desckey": 'TL',
		"defaultflag": 'N'
	},
	{
		"id": 'TM',
		"desckey": 'TM',
		"defaultflag": 'N'
	},
	{
		"id": 'TN',
		"desckey": 'TN',
		"defaultflag": 'N'
	},
	{
		"id": 'TO',
		"desckey": 'TO',
		"defaultflag": 'N'
	},
	{
		"id": 'TR',
		"desckey": 'TR',
		"defaultflag": 'N'
	},
	{
		"id": 'TT',
		"desckey": 'TT',
		"defaultflag": 'N'
	},
	{
		"id": 'TV',
		"desckey": 'TV',
		"defaultflag": 'N'
	},
	{
		"id": 'TW',
		"desckey": 'TW',
		"defaultflag": 'N'
	},
	{
		"id": 'TZ',
		"desckey": 'TZ',
		"defaultflag": 'N'
	},
	{
		"id": 'UA',
		"desckey": 'UA',
		"defaultflag": 'N'
	},
	{
		"id": 'UG',
		"desckey": 'UG',
		"defaultflag": 'N'
	},
	{
		"id": 'UM',
		"desckey": 'UM',
		"defaultflag": 'N'
	},
	{
		"id": 'US',
		"desckey": 'US',
		"defaultflag": 'N'
	},
	{
		"id": 'UY',
		"desckey": 'UY',
		"defaultflag": 'N'
	},
	{
		"id": 'UZ',
		"desckey": 'UZ',
		"defaultflag": 'N'
	},
	{
		"id": 'VA',
		"desckey": 'VA',
		"defaultflag": 'N'
	},
	{
		"id": 'VC',
		"desckey": 'VC',
		"defaultflag": 'N'
	},
	{
		"id": 'VE',
		"desckey": 'VE',
		"defaultflag": 'N'
	},
	{
		"id": 'VG',
		"desckey": 'VG',
		"defaultflag": 'N'
	},
	{
		"id": 'VI',
		"desckey": 'VI',
		"defaultflag": 'N'
	},
	{
		"id": 'VN',
		"desckey": 'VN',
		"defaultflag": 'N'
	},
	{
		"id": 'VU',
		"desckey": 'VU',
		"defaultflag": 'N'
	},
	{
		"id": 'WF',
		"desckey": 'WF',
		"defaultflag": 'N'
	},
	{
		"id": 'WS',
		"desckey": 'WS',
		"defaultflag": 'N'
	},
	{
		"id": 'YE',
		"desckey": 'YE',
		"defaultflag": 'N'
	},
	{
		"id": 'YT',
		"desckey": 'YT',
		"defaultflag": 'N'
	},
	{
		"id": 'ZA',
		"desckey": 'ZA',
		"defaultflag": 'N'
	},
	{
		"id": 'ZW',
		"desckey": 'ZW',
		"defaultflag": 'N'
	},
	{
		"id": 'ZM',
		"desckey": 'ZM',
		"defaultflag": 'N'
	}]
}));