define({
		"compose": "Send us a message",
        "resend": "Resend",
        "send": "Send",
		"reply":"Reply",
		"delete":"Delete",
		"cancel":"Cancel",
		"contactUs":"Contact us",
		"warningMessage":"Please correct the errors shown and try again.",
		"noMessageWarning":"You have no messages",
		"lostStolenCardTitle":"Lost or Stolen Card",
		"lostStolenCardInstructionLine1":"We treat unrecognised transaction enquiries as urgent, so please call us instead of sending a message.",
		"lostStolenCardInstructionLine2":"UK: 03456 007 010",
		"lostStolenCardInstructionLine3":"Overseas: +44 1442 422 929",
		"lostStolenCardInstructionLine4":"Textphone: 08457 125563",
		"contactFooter":"We aim to respond to your enquiry within two working days. If we cannot resolve your enquiry we will contact you. If your request is urgent, please contact us by telephone.",
		"messageSent":"Your message has been sent",
		"success":"Success",
		"alertMsg":"Alert",
		"messageSentDescriptionHead":"We aim to respond to your enquiry within two working days",
		"messageSentDesHeadAdv":"We aim to respond to your enquiry within two working days. If your request is urgent, please contact us by telephone.",
		"messageSentDescriptionBody":"Thank you for contacting HSBC. Your message was successfully submitted and we will respond to your request within 48 hours.",
		"sentOn":" at",
		"gmt" :" GMT",

		"messageFailureDescriptionHead":"Please retry after sometime!!",
		"messageFailureDescriptionBody":"Thank you for contacting HSBC. Your message was successfully submitted and we will respond to your request within 48 hours.",
		"messageFailed":"Your message has not been sent.",


		"backToMsg":"Back to messages",
		"wrtMsgPlcHlder":"Write your message here",

		"composeTxtareaPlaceHolder":"Write your message here",
		"replyTxtareaPlaceHolder":"Write your message here",

		"requestAContact":"Request A Contact",
		"enquiryTopic":"Enquiry topic",
		"timeOfContact":"Time of contact",
		"contact":"Contact",
		"tooltiptext":"Your details can be found and amended in Personal Details.",
		"request":"Request",
		"home":"Home",
		"work":"Work",
		"mobile":"Mobile",
		"fax":"Mobile",
		"email":"Email",
		"contactNumber":"Contact Number",
		"time":"Morning",
		"Product Type":"Checking: Current Account",
		"Additional information":"Additional information",

		"deleteDialogHeaderText": "Delete Message",
		"deleteDialogYes": "Delete",
		"deleteDialogNo": "Don't delete",
		"deleteDialogText": "Are you sure you want to delete this message?",

		"cancelDialogHeaderText": "Are you sure you want to cancel this message?",
		"cancelDialogYes": "Cancel",
		"cancelDialogNo": "Don't cancel",
		"cancelDialogText": "Any changes you have made will be lost.",

		"unsavedMsgDialogHeaderText": "Discard Unsent Message",
		"unsavedMsgDialogText": "Navigating away from this form will result in the loss of any unsent messages. Are you sure you wish to discard your unsent messages?",
		"unsavedMsgDialogYes": "Yes",
		"unsavedMsgDialogNo": "No",

		"messageSubject": "What is your enquiry about?",
        "subjectPlaceHolder": "Select a subject",
        "specifyReason": "Please specify the reason for the email",
        "newMessage": "New message",
        "subject": "Subject",
        "subjectTitle": "What is your enquiry about?",
        "relatedAccount": "Account",
        "loading": "Loading",
        "composeMessage" : "New message",
        "replyMessage" : "Reply Message",
        "replyDefaulTitle": "Title",
        "emptyMessage":"Please write your subject",
        "tooLongMessage":"Your message has maximum of 40 characters",
        "opensDialog": "Opens a dialog",
		"replySubject":"RE:",
		"contactFooterHeader" : "We aim to respond to your enquiry within two working days. If your request is urgent, please contact us by telephone.",
		"contactFooterHead":"We aim to respond to your enquiry within 2 working days.",
		"contactFooterBody":"We will contact you if we cannot answer your enquiry. Please tell us when we can call you and on which number.",
		"specialcharwarningMessage":"Special characters ! ~ < > [ ] ^ |  are not allowed.",
		"emptytextMessage":"Please write your message here",
		"longMessage":"Your message cannot exceed 2900 characters",
		"secureMessage": "Messages | HSBC",
		"printMessage": "My message",
    	"opensPrintPreviewOverlay": " Opens print preview overlay",
		"print": "Print",
		"noReply":"You cannot reply to this message.",
		"from":"From:",
		"accountDetails":"Account details:",
		"message": "Message:",
	    "to": "To:",
		"expandMsg":"Select to expand",
		"collapseMsg":"Select to collapse",
		"collapseMsgForComposeSection":"Expanded Compose new message section",
		"deleteMsg":"Delete",
		"lostsl":{
			"sendBlockHelpTextHead":"If your card has been lost or stolen you should take action immediately",
			"sendBlockHelpTextInfo":"Please <a style='text-decoration:underline;' href='https://servicing.hsbc.co.uk/servicing/lost-stolen-card/#/step-one'>report lost or stolen card</a> or call us.",
			"sendBlockHelpTextContactsHead":"Contact numbers for lost or stolen cards",
			"sendRestrictContacts":[
			                        {
			                        	"id":"1",
			                        	"description":"UK",
			                        	"contact":"0800 085 2401"
			                        },
			                        {
			                        	"id":"2",
			                        	"description":"Overseas",
			                        	"contact":"+44 1442 422 929"
			                        }
			                        ]
		},
		"unrtra":{
			"sendBlockHelpTextHead":"If you see a transaction you don't recognise, select <a style='text-decoration: underline;' href='https://www.hsbc.co.uk/1/2/contact-and-support/card-support/query-transaction'>Query transaction</a> to be taken to information that may help you identify it.",
			"sendBlockHelpTextInfo":"If you still don't recognise the transaction, as it's urgent, please call us instead of sending a message.",
			"sendBlockHelpTextContactsHead":"Contact numbers for Unrecognized transaction",
			"sendRestrictContacts":[
			                        {
			                        	"id":"1",
			                        	"description":"UK",
			                        	"contact":"03456 007 010"
			                        },
			                        {
			                        	"id":"2",
			                        	"description":"From outside the UK",
			                        	"contact":"+44 1442 422 929 <br/> Lines are Open 24 hrs"

			                        },
			                        {
			                        	"id":"3",
			                        	"description":"Textphone from within the UK",
			                        	"contact":"0800 028 3516"
			                        },
			                        {
			                        	"id":"4",
			                        	"description":"From outside the UK",
			                        	"contact":"+44 1792 494 394 <br/> Lines are Open 24 hrs"

			                        }
			                        ]
		},
		"preferedCallTime":"Preferred call time",
		"phoneNumbers":"Which phone number(s) can we contact you on?",
		"invalidPhone":"Please enter valid phone number",
		"enterNumber":"Enter number",
		"phoneNumbersToContactError":"Please, select one phone number",
		"temporaryPhoneNumber":"Temporary phone number",
		"am":"am",
		"pm":"pm",
		"titleMsg" : "Discard Unsent Message",
		"msgText" : "Navigating away from this form will result in the loss of any unsent messages. Are you sure you wish to discard your unsent messages?",
		"yesDiscard" : "Yes",
		"noReturn" : "No",
		"temporaryDaytimeNumber":"Preferred number",
		"temporaryEveningNumber":"Preferred number",
		"contactUsFooterBody":"If your request is urgent you may want to contact us by telephone.",
		"contactUsFooterHead":"Urgent enquiries",
		"customerSupport": "Customer Support",
		"customerSupportText":"Have a question or need help? if you need assistance please visit our Customer Support section.",
		"fullFormattedDate" : "dd MMM y",
		"preferredTime" : {
		    "am" : "1",
		    "pm" : "2"
		},
		"customerContactInfo":{
			"preferedCallTime":[
				{
					"label":"AM",
					"value":"am"
				},
				{
					"label":"PM",
					"value":"pm"
				}
			],
			"contactNumbers":[],
			"countryCode":[
				{
					"label":"United Kingdom",
					"value":"+44"
				},
				{
					"label":"United States",
					"value":"+1"
				}
			]

		},
		"custEntities":{
			"customerContactInfo":{
				"preferedCallTime":[
					{
					"label":"AM",
					"value":"am"
				},
				{
					"label":"PM",
					"value":"pm"
				}
				],
				"countryCode":[
					{
						"label":"United Kingdom",
						"value":"+44"
					},
					{
						"label":"United States",
						"value":"+1"
					}
				]

			}
		}

});
