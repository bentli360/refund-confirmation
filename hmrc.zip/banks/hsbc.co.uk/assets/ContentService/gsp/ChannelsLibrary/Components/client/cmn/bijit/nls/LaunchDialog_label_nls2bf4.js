/**
 *
 */
define({
	root : ({
		'proceedWarningTitle' : '',
		'proceedWarningContent' : "Selecting Proceed will open a website in a new window, outside of the HSBC secure environment. Your Online Banking session will remain open in the background. <br><br>Take care not to leave your device unattended, and remember to log off when you have finished. If you don't return to Online Banking within 10 minutes you will be logged off automatically.",
		'acceptAndProceed' : 'Proceed',
		'cancel' : 'Cancel',
		'proceedWarningContentMCAB' : "<b>Book or manage appointment</b><br><br>Selecting 'Accept and proceed' will launch a new browser window where you can book or manage your appointment. Your online banking pages will remain open in the background. If you don't return to online banking within 10 minutes you will be logged out for security. Just log on again if you need to."
	}),
	"es-ar" : true,
	"hi-in" : true,
	"en-je" : true,
	"ar-sa" : true,
	"en-hk" : true,
	"zh-cn" : true,
	"zh-hk" : true,
	"en-gb" : true
});
