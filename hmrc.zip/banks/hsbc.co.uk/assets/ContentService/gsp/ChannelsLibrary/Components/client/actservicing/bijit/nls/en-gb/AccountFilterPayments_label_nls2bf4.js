define({
	"searchAmountRange" : {
		"to" : "To",
		"from" : "From ",
		"toLabel" : "To",
		"fromLabel" : "From",
		"divider" : "-",
		"fromErrorMsg" : "From amount is not valid",
		"toErrorMsg" : "To amount is not valid",
		"compareErrorMsg" : "To amount must be greater than the From amount",
		"bothAmountsTheSameErrorMsg" : "From and To amounts can not be the same.",
		"toPlaceholder" : "To",
		"fromPlaceholder" : "From"
	},

	"printResults_CC" : "Print results",
	"downloadResults_CC" : "Download results",
	"downloadAs" : "Download as",
	"csv" : "CSV",
	"quicken" : "QFX (Quicken)",
	"qif" : "QIF",
	"ofx" : "OFX",
	"downloadMsg" : "",
	"searchNameInvalidMsg" : "Your search can be 2-35 characters in length and can contain these characters: a-z, A-Z, 0-9, plus /_-?:().,+",
	"recent" : "Recent transactions",
	"formatSelect" : "Select format",
	"periodSelect" : "Select period",
	"statementsAlert" : "There are no previous statements to display for this account. Please try later.",
	"statementsError" : "There are no historic transactions for this account. Please try a different date period.",
	"disclaimerHeading" : "Disclaimer",
	"disclaimerBDate" : "The earliest date you can view is ${duration}. To view earlier transactions, select Statements from the Manage menu.",
	"disclaimerHCADate" : "The earliest date you can view is ${duration}. To view earlier transactions refer to your paper statements.",
	"disclaimerHDate" : "Enter details in the fields shown to search your recent transactions.",
	"disclaimerCCDate" : "Enter details in the fields shown to search your recent transactions. To view earlier transactions, select Statements from the Manage menu.",
	"termUnit" : {
		"month":"months",
		"day":"days",
		"year":"years"
	},
	"searchDateRange" : {
		"to" : "DD/MM/YYYY",
		"from" : "DD/MM/YYYY",
		"toLabelText" : "to",
		"fromLabelText" : "from",
		"fromLabel" : "From",
		"toLabel" : "To",
		"divider" : "-",
		"fromErrorMsg" : "The From date is not valid",
		"toErrorMsg" : "The To date is not valid",
		"compareErrorMsg" : "The To date must be after the From date",
		"bothDatesTheSameErrorMsg" : "From and To dates can not be the same.",
		"futureDateError" : "Date should not be in future",
		"toPlaceholder" : "To",
		"fromPlaceholder" : "From"
	},
	"months" : {
		"1" : "January",
		"2" : "February",
		"3" : "March",
		"4" : "April",
		"5" : "May",
		"6" : "June",
		"7" : "July",
		"8" : "August",
		"9" : "September",
		"10" : "October",
		"11" : "November",
		"12" : "December"
	},
	
	// HUB date for Local systems
	"localhost:9080_FCA_HUB_Date" : "Tue Aug 07 2014 00:00:00 GMT+0530 (India Standard Time)",
	
	// HUB date for Local systems
	"localhost:9083_FCA_HUB_Date" : "Tue May 19 2015 00:00:00 GMT+0530 (India Standard Time)",
	
	// HUB date for Cloud systems
	"hkl100401.hk.hsbc:20100_FCA_HUB_Date" : "Tue Aug 07 2014 00:00:00 GMT+0530 (India Standard Time)",
	"hkl100088.hk.hsbc:20100_FCA_HUB_Date" : "Tue Aug 07 2014 00:00:00 GMT+0530 (India Standard Time)",
	
	// HUB date for DIT systems
	"hkl100845-uk-oneclick.hk.hsbc_FCA_HUB_Date" : "Tue May 19 2015 00:00:00 GMT+0530 (India Standard Time)",
	"hkl100259-uk-oneclick.p2g.netd2.hk.hsbc_FCA_HUB_Date" : "Tue May 19 2015 00:00:00 GMT+0530 (India Standard Time)",
	"hkl101281-uk-oneclick.p2g.netd2.hk.hsbc_FCA_HUB_Date" : "Tue May 19 2015 00:00:00 GMT+0530 (India Standard Time)",
	
	// HUB Date for PT5
	"www.hkgv2ls0397-uk.p2g.netd2.hsbc.com.hk_FCA_HUB_Date" : "Tue May 19 2015 00:00:00 GMT+0530 (India Standard Time)",
	"www.hkgv2ls0294-uk.p2g.netd2.hsbc.com.hk_FCA_HUB_Date" : "Tue May 19 2015 00:00:00 GMT+0530 (India Standard Time)",
	
	// HUB Date for PT6
	"www.hkgv2ls0404-uk.p2g.netd2.hsbc.com.hk_FCA_HUB_Date" : "Tue May 19 2015 00:00:00 GMT+0530 (India Standard Time)",
	"www.hkg2vl0463-uk.p2g.netd2.hsbc.com.hk_FCA_HUB_Date" : "Tue May 19 2015 00:00:00 GMT+0530 (India Standard Time)",
	
	// HUB Date for RC
	"www.hkgv2ls0183-uk.p2g.netd2.hsbc.com.hk_FCA_HUB_Date" : "Wed Aug 07 2014 00:00:00 GMT+0530 (India Standard Time)"
		
});
