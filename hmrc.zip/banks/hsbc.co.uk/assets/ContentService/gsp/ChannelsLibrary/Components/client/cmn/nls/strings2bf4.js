/**
 * NLS bundles for page controllers
 */
define({
	root : ({
	    'rightToLeft' : false,
		'SCMPageController_campaignDetailsTitle' : 'Campaign Details',
		'phonenumbers_title' : "Useful phone numbers",
		'contactme_title' : "Have an Advisor contact me",
		'makeappointment_title' : "Make an appointment in Branch",
		'loadingMsg' : "<strong>Please wait</strong> <br/> We are processing your data...",
		'loadingMsg_title' : "Please wait, We are processing your data...",
		'returnToDashboard' : 'Return to Dashboard',
		'lorem' : "lorem",
		'newslettersub' : "Newsletter subscriptions",
		'pleaseSelect' : "Please select",
		'pageTitle' : "My profile",
		'dormancylnkerror' : "Abnormal HIB customer status, pls contact branch",
		'dormancynonlnkerror' : "Abnormal HIB customer status, pls contact branch",
		"ReceiptRetrievalPageController_heading" : "Recent activity",
		"filterButton" : "Filter this list",
		"profileManage" : "Profile Management",
		"ContactInformationPageController_profileManage" : "Profile Management",
		'searchresult_search' : 'Search',
		'searchresult_title' : 'Search',
		'ContactRMController_contactRM' : 'Contact HSBC',
		'ContactRMController_contactRM_title' : 'Contact HSBC',
	    'filter' : "Filter activities",
	    'CommunicationPreferencesController_Title' : 'Documents',
	    'ContactInformationPageController_Title' : 'Account Management',
		'ReqPaperCopy_Title':'Documents'
	}),
	"es-ar" : true,
	"ar-sa" : true,
	"hi" : true,
    "en-je" : true,
    "en-ph" : true,
    "en-gb" : true,
    "en-eg" : true,
    "ar-ae" : true,
    "zh-cn" : true,
    "zh-hk" : true
});
