define({
	root: ({
"title"  : "How to report lost or stolen Card",
"heading"  : "General contact numbers",
"country"  : "UK",
"textphone"  : "Textphone",
"overseas"  : "Overseas",
"call"  : "Call",
"number1"  : "0845 007 010",
"number2"  : "08457 125563",
"number3"  : "+44 1442 422 929",
"close"  : "Close",
"overseas_Phone":"From outside the UK"
}),
"es-ar" : true,
"ar-sa" : true,
"hi-in" : true,
"en-je" : true,
"en-gb" : true,
"en-ph" : true,
"en-hk" : true,
"zh-cn" : true,
"zh-hk" : true,
"ar-ae" : true
});
