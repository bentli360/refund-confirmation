define({
	    "unSupportedRecurringMsg" : "Recurring payments can\'t be made in a foreign currency.",
		'to' : 'Move money to',
        'toAccntReqMsg' : 'This value is required',
		'myAccounts': "My accounts",
        'account' : 'Account',
        'myPayees' : 'My payees',
        'newPayee' : 'New payee',
        'lockIconNewpayee' : '<span class="locked"></span>',
        'myAccountsLabel':'Account'
});
