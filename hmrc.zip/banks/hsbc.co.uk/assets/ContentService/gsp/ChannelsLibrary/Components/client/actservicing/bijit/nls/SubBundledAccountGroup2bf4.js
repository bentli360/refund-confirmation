define({
    "root": {
        "payment": "Payment",
        "transfer": "Transfer",
        "viewRecentTransactionsFor": "View Recent transactions for:",
        "indicativeBalance": "Indicative Balance",
        "hyphen": " - "
    }
    
});
