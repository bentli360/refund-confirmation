define({
	"bannerType":"SCM",
	"imageSrc":"https://www.services.online-banking.hsbc.co.uk/ContentService/gsp_gb/ChannelsLibrary/Components/client/mcm/image/",	
	"newBannerStyle" : {
							"bijitClass" : "ukBanner",
							"adLocationClass" : "newBanner",
							"carousel" : {
											"bijitClass" : "ukCarausalBanner",
											"adLocationClass" : "carBanner",
										 }
					   },
		"GSP_Lightbox":{
			"bannerType":"MCM",
			"htmlId": "GSP_Lightbox"
		},
		"DASHBOARD_1" :{
			"bannerType":"MCM",
			"htmlId": "GSP_MyaccountWest"
		},
		"DASHBOARD_2" :{
			"bannerType":"MCM",
			"htmlId": "GSP_MyaccountSouth"
		},
		"DASHBOARD_3" :{
			"bannerType":"MCM",
			"htmlId": "GSP_MyaccountNorth"
		},
		"DASHBOARD_4" :{
			"bannerType":"MCM",
			"htmlId": "GSP_MyaccountEast"
		},
		"TRANSCATION_TOP":{
			"bannerType":"MCM",
			"htmlId": "GSP_movenorth"
		},
		"TRANSCATION_LEFT":{
			"bannerType":"MCM",
			"htmlId": "GSP_movewest"
		},
		"TRANSCATION":{
			"bannerType":"MCM",
			"htmlId": "GSP_movesouth"
		},
		"LINK_GLOBAL_VIEW_TOP":{
			"bannerType":"MCM",
			"htmlId": "GSP_globalnorth"
		},
		"LINK_GLOBAL_VIEW_LEFT":{
			"bannerType":"MCM",
			"htmlId": "GSP_globalwest"
		},
		"LINK_GLOBAL_VIEW":{
			"bannerType":"MCM",
			"htmlId": "GSP_globalsouth"
		},
		"GVCONF_2":{
			"bannerType":"MCM",
			"htmlId": "GSP_globalsouth"
		},
		"GVCONF_1":{
			"bannerType":"MCM",
			"htmlId": "GSP_globalwest"
		},
		"GVCONF_3":{
			"bannerType":"MCM",
			"htmlId": "GSP_globalnorth"
		},
		"SESSION_POPUP":{
			"bannerType":"SCM",
			"htmlId": "GSP_seesiontimeout"
		},
		"VWDWNST_1":{
			"bannerType":"MCM",
			"htmlId": "VWDWNST_1"
		},
		"VWDWNST_2":{
			"bannerType":"MCM",
			"htmlId": "VWDWNST_2"
		},
		"VWDWNST_3":{
			"bannerType":"MCM",
			"htmlId": "VWDWNST_3"
		}
});