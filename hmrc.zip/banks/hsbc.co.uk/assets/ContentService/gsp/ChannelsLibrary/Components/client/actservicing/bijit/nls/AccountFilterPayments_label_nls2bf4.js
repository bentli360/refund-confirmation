define({
	root : ({
		"slctAtleastOneerrorsnoTransactionAvailable" : "You have not chosen any search criteria",
		"searchByName" : "Search by name",
		"searchByAmount" : "Search by amount",
		"printResults" : "Print results",
		"printResults_CC" : "Print",
		"opensDialog" : "Opens a dialog",
		"disclaimerHeading" : "Disclaimer",
		"disclaimerBDate" : "You can view transactions for this account from the last ${duration} ${unit}. To view older transactions, visit download statements.",
		"termUnit" : {
			"month":"months",
			"day":"days",
			"year":"years"
		},
		"searchAmountRange" : {
			"to" : "To",
			"from" : "From ",
			"toLabel" : "To",
			"fromLabel" : "From",
			"divider" : "-",
			"fromErrorMsg" : "From amount is not valid",
			"toErrorMsg" : "To amount is not valid",
			"compareErrorMsg" : "To amount must be greater than the From amount",
			"bothAmountsTheSameErrorMsg" : "From and To amounts can not be the same.",
			"toPlaceholder" : "To",
			"fromPlaceholder" : "From"
		},
		"date" : "Date",
		"searchDateRange" : {
			"to" : "DD/MM/YYYY",
			"from" : "DD/MM/YYYY",
			"toLabelText" : "to",
			"fromLabelText" : "from",
			"toLabel" : "To",
			"fromLabel" : "From",
			"divider" : "-",
			"fromErrorMsg" : "The From date is not valid",
			"toErrorMsg" : "The To date is not valid",
			"compareErrorMsg" : "The To date must be after the From date",
			"bothDatesTheSameErrorMsg" : "From and To dates can not be the same.",
			"futureDateError" : "You cannot choose a future date to filter transactions. Please choose another date.",
			"toPlaceholder" : "To",
			"fromPlaceholder" : "From"
		},
		"searchToAmount" : "Search to amount",
		"validDate" : "Enter an valid date",
		"validAmount" : "Enter an valid amount",
		"toAmountGreaterText" : "To amount should be greater than the from amount",
		"maxTransactionReached" : "You have reached the maximum numbers of transactions. Older bill payments can be accessed",
		"viaAccountTransactions" : "via account transactions",
		"noResultsFound" : "No results have been found",
		"searchFilters" : "Filter bill payment",
		"clearResults" : "Clear results",
		"viewResults" : "View results",
		"downloadResults" : "Download results",
		"downloadResults_CC" : "Download",
		"moveMoney" : "Move Money",
		"downloadAs" : "Download as",
		"csv" : "Spreadsheet (CSV)",
		"quicken" : "Quicken (QFX)",
		"qif" : "Quicken (QIF)",
		"ofx" : "Open Financial Exchange (OFX)",
		"downloadMsg" : "Quicken and CSV files may need additional software in order to read them. HSBC is not responsible for accessibility of the downloaded files",
		"cancel" : "Cancel",
		"submit" : "Download",
		"select" : "Select",
		// "www.cddas401-je.p2g.netd2.hsbc.com.hk_HUB_Date" : "Mon Apr 13 2015
		// 00:00:00 GMT+0530 (India Standard Time)",
		// "www.cddas376-je.p2g.netd2.hsbc.com.hk_HUB_Date" : "Mon Jun 16 2014
		// 00:00:00 GMT+0530 (India Standard Time)",
		// "www.cddas346-je.p2g.netd2.hsbc.com.hk_HUB_Date" : "Fri May 31 2013
		// 00:00:00 GMT+0530 (India Standard Time)",
		// "hkl100232.hk.hsbc : "20100_HUB_Date" : "Tue May 26 2015 00:00:00
		// GMT+0530 (India Standard Time)"",

		// "hkl100088.hk.hsbc : "20100_HUB_Date" : "Tue Feb 08 2016 00:00:00
		// GMT+0530 (India Standard Time)"",
		// "hkl100602-hk-oneclick.hk.hsbc_HUB_Date" : "Tue Feb 08 2016 00:00:00
		// GMT+0530 (India Standard Time)",
		// "hkl100604-hk-oneclick.hk.hsbc_HUB_Date" : "Tue Feb 08 2016 00:00:00
		// GMT+0530 (India Standard Time)",

		// "www.hkgv2ls0189-je.p2g.netd2.hsbc.com.hk_HUB_Date" : "Fri Jan 09
		// 2015 00:00:00 GMT+0530 (India Standard Time)",

		// "localhost : "9080_HUB_Date" : "Mon Mar 06 2015 00:00:00 GMT+0530
		// (India Standard Time)"",
		// "wsp904820wss.in.hsbc : "9080_HUB_Date" : "Mon Jul 04 2011 00:00:00
		// GMT+0530 (India Standard Time)"",
		// "136.49.104.59 : "9080_HUB_Date" : "Tue Nov 04 2014 00:00:00 GMT+0530
		// (India Standard Time)"",
		// "a356i7lzx42dvc3.in.hsbc : "9080_HUB_Date" : "Wed Jul 16 2014
		// 00:00:00 GMT+0530 (India Standard Time)"",
		// "hkl100098.hk.hsbc : "20100_HUB_Date" : "Tue Nov 04 2014 00:00:00
		// GMT+0530 (India Standard Time)"",

		"slctAtleastOne" : "Please select at least one filter criteria.",
		"slctValidTxnHistType" : "Please select valid transaction history type.",
		"select" : "Select",
		"opensPrintPreviewOverlay" : " Opens print preview overlay"
	}),
	"es-ar" : true,
	"ar-sa" : true,
	"en-je" : true,
	"en-gb" : true,
	"en-ph" : true,
	"en-sa" : true,
	"hi-in" : true,
	"en-ae" : true,
	"ar-ae" : true,
	"zh-cn" : true,
	"zh-hk" : true,
	"en-hk" : true,
	"en-eg" : true

});
