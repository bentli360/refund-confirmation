define(({
		"Select" : 'Please Select',
		"ENGLISH" : 'English',
		"CHINESE" : 'Simplified Chinese',
		"PORTUGUESE" : 'Portuguese',
		"FRENCH" : 'French',
		"INDONESIAN" : 'Indonesian',
		"TCHINESE" : 'Traditional Chinese',
		"SPANISH" : 'Spanish',
		"JAPAENSE" : 'Japanese',
		"THAI" : 'Thai'
}));