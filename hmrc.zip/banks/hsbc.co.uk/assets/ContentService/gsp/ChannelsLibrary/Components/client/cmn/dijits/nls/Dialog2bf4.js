define({
    root: {
        title: "Cancel Operation?",
        message: "Are you sure you want to cancel?",
        yes: "Cancel",
        no: "Don't Cancel",
        accessibleYes: "Perform the requested operation",
        accessibleNo: "Abandon the operation and close the dialog",
        buttonClose: "Close",
        confirmationDialog: "Confirmation dialog",
        areYouSure: "Are you sure you want to cancel?",
        changesWillNotBeSaved: "Any changes you have made will be lost",
        returnToDashboard: "Return to dashboard",
        closesDialog: "Closes dialog"
    },
"zh-hk": true,
"zh-cn": true,
    "es-ar" : true,
    "en-hk" : true
});
