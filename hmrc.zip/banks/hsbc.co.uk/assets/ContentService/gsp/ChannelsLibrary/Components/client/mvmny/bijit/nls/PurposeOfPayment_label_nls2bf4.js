define({
	root : ({
		'popLabelDom' : 'Purpose of transaction',
		'purOfDbPymtLabel' : 'Purpose of transaction for debiting account',
		'purOfCrPymtLabel' : 'Reason for payment',
		'purOfIntlPymtLabel': "Reason for transaction",
		'requiredMsg': "Please enter a reason for transaction",
		'requiredMsgM2mIntl': "Please enter a reason for payment",
		'purOfPymtLabelOpt' : 'Optional',
		'select' : 'Select',
		'trnRsn' : 'Please enter the Transfer Reason',
		'fieldInvalidMessage' : 'The field must be between 0 and 24 characters long. It should contain only the following characters a-z, A-Z, 0-9, plus /_-?:().,+',
		'payeepurposeoftxn':'Payee purpose of transaction',
		'transferReason' : 'Transfer Reason',
		"creditPurposeOfPayment" :"Credit purpose of payment",
		"gtffRequiredMsg" :"Please select the credit purpose of payment option",
		 "gtffDebitOtherMissingMsg" : "Please enter a reason for this transaction"
	}),
"zh-cn": true,
"zh-hk": true,
	"es-ar": true,
	"hi-in" : true,
    "en-je" : true,
	"en-gb" : true,
	"en-ph" : true,
"en-eg" : true,
	"en-hk" : true
});
