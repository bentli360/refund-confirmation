﻿define({
	"m2mdomestic" : "https://www.hsbc.co.uk/1/2/popups/payment-limits",
	"m2minternational" : "https://www.hsbc.co.uk/1/2/popups/payment-limits#meta",
	"m2nmdomesticOtherBank" : "https://www.hsbc.co.uk/1/2/popups/payment-limits",
	"m2nmdomesticOtherHSBC" : "https://www.hsbc.co.uk/1/2/popups/payment-limits",
	"m2nminternational" : "https://www.hsbc.co.uk/1/2/popups/payment-limits",
	"m2company" : "https://www.hsbc.co.uk/1/2/popups/payment-limits",
	"m2nmintlcutoff":"http://www.hsbc.co.uk/1/2/personal/online-banking/contextual-help/international-payments-cutoff"
});
