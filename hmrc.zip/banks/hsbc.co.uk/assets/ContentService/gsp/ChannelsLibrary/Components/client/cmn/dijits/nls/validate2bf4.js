define({ root:
{
	invalidMessage: "The value entered is not valid.",
	missingMessage: "This is a mandatory field. Please complete it.",
	rangeMessage: "This value is out of range."
},
"en-gb": true,
"en-hk": true,
"zh-hk": true,
"zh-cn": true,
"es-ar":true
});
