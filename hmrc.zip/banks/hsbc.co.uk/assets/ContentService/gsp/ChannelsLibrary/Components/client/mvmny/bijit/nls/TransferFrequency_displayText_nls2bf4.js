define({
	root : ({
		'Select' : 'Select',
		'daily' : 'Daily',
		'weekly' : 'Weekly',
		'everyTwoWeeks' : 'Every 2 weeks',
		'bimonthly' : 'Twice a month',
		'monthly' : 'Monthly',
		'fortnightly' : 'Every two weeks',
		'lastdayofthemonth' : 'Last day of the month',
		'lastdayoftheyear' : 'Last day of the year',
		'every2months' : 'Every 2 months',
		'quarterly' : 'Quarterly',
		'halfyearly' : 'Half-yearly',
		'Yearly' : 'Yearly',
		'annually' : 'Yearly'
	}),
	"zh-cn": true,
	"zh-hk": true,
	"es-ar": true,
	"hi-in" : true,
	"en-je" : true,
	"en-gb" : true,
	"en-ae" : true,
	"en-hk" : true,
	"sa-ar" : true,
	"en-eg" : true
});
