define(({
	root : ({
		content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, recusandae, corporis molestiae consequatur at quibusdam eaque sunt dolores amet vero eum quaerat unde similique officiis debitis maxime ut ea praesentium." +
				"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, recusandae, corporis molestiae consequatur at quibusdam eaque sunt dolores amet vero eum quaerat unde similique officiis debitis maxime ut ea praesentium." +
				"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, recusandae, corporis molestiae consequatur at quibusdam eaque sunt dolores amet vero eum quaerat unde similique officiis debitis maxime ut ea praesentium." +
				"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, recusandae, corporis molestiae consequatur at quibusdam eaque sunt dolores amet vero eum quaerat unde similique officiis debitis maxime ut ea praesentium."
	}),
	"hi-in" : true
}));
