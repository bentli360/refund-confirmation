/**
 * NLS bundles for page controllers
 */
define({
	"loadingMsg" : "<strong>Please wait</strong> <br/> We are loading your data...",
	"loadingMsg_title" : "Please wait, We are loading your data...",
	"ContactInformationPageController_Title" : "My profile",
	"CommunicationPreferencesController_Title" : "Documents",
	"ReqPaperCopyController_ReqPaperCopy_Title" : "Documents"
});