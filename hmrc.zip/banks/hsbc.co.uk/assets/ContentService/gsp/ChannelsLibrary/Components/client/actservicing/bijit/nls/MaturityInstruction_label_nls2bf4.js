define({
	root : {
		"RENW1" : "Renew for a new term - Include interest",
		"RENW2" : "Renew for a new term - Withdraw interest",
		"ADFUND" : "Renew and add funds",
		"WITDRW" : "Renew and withdraw funds",
		"NORENW" : "Do not renew",
		
		"CL1" : "Withdraw principal/guaranteed principal + interest (if any) to account : {0} {1} on {2}",
		"CL2" : "Withdraw principal/guaranteed principal + interest (if any) to account : unspecified account",
		"CL3" : "No Instruction",
		
		"FX1" : "Withdraw principal/guaranteed principal + interest (if any) to account : {0} {1}",
		"FX2" : "Withdraw principal/guaranteed principal + interest (if any) to account : unspecified account",
		"FX3" : "Full Renew For {0} {1} Fixed ",
		"FX4" : "Full Renew For {0} {1}",
		"FX5" : "Renew principal/guaranteed principal for {0} {1} ' Fixed ' and withdraw interest/return (if any) to account {2} {3}",
		"FX6" : "Renew principal/guaranteed principal for {0} {1} 'Call' and withdraw interest/return (if any) to account {2} {3}",
		"FX7" : "Renew principal/guaranteed principal for {0} {1} and withdraw interest/return (if any) to account {2} {3}",
		"FX8" : "Renew principal/guaranteed principal for {0} {1}",
		"FX9" : "Renew {0} {1} for {2} {3}  'Fixed ' and transfer the difference to/from account {4} {5}",
		"FX10" : "Renew {0} {1} for {2} {3}  and transfer the difference to/from account {4} {5}",
		"FX11" : "Renew {0} {1} for {2} {3} and transfer the difference to/from account {4} {5}",
		"FX12" : "Renew {0} {1} for {2} {3}",
		"FX13" : "The instruction will not be processed due to insufficient balance at maturity, please modify your maturity instruction",
		"FX14" : "No Instruction",
		
		"CP1" : "Early redemption request placed. Early redemption settlement on {0} 2 HK & reference currency business days to account {1} {2}",
		"CP2" : "Withdraw principal/guaranteed principal + interest (if any) to account : {0} {1} or {2} {3}",
		"CP3" : "Withdraw principal/guaranteed principal + interest (if any) to account : {0} {1}",
		"CP4" : "Full Renew For {0}, {1}  or {2} {3}",
		"CP5" : "Full Renew For {0}, {1}",
		"CP6" : "Renew principal/guaranteed principal for {0} , {1} and withdraw interest/return (if any) to account {2} {3} or {4} {5}",
		"CP7" : "Renew principal/guaranteed principal for {0} , {1} and withdraw interest/return (if any) to account {2} {3}",
		"CP8" : "Renew {0} {1} for {2}, {3} and transfer the difference to/from account {4} {5} or {6} {7}",
		"CP9" : "Renew {0} {1} for {2}, {3}and transfer the difference to/from account {4} {5}",
		
		"PS1" : "Principal will be rolled over to place the Structured Investment Deposit Interest will be repaid to account {0}",
		"PS2" : "Withdraw Principal/Guaranteed Principal + interest (if any) to account {0} or {1}",
		"PS3" : "Withdraw Principal/Guaranteed Principal + interest (if any) to account {0}",
		
		"DP1" : "The Bank shall repay and credit {0} {1} to {0} {2}",
		"DP2" : "The Bank shall repay and credit:<br>(i) {1} to {2} if the Final Exchange Rate is {3} than or equal to {4}, or<br>(ii) {5} to {6} if the Final Exchange Rate is {3} than {4}.",
		"DP3" : "If FX Rate has{0} traded at or {1} {2} during the Observation Period, the Bank shall repay and credit {3} to {4}.<br>If FX Rate has{0} traded at or {1} {2} during the Observation Period, the Bank shall repay and credit:<br>(i) {3} to {4} if the Final Exchange Rate is {5} than or equal to {6},or<br>(ii) {7} to {8} if the Final Exchange Rate is {5} than {6}.",
		"DP4" : "The Bank shall repay and credit:<br>(i) {0} to {1} if the Final Exchange Rate is {2} than or equal to {3}, or<br>(ii) {4} to {5} if the Final Exchange Rate is {2} than {3}.",
		"DP5" : "No Instruction"

	},
"zh-cn": true,
"zh-hk": true,
"en-hk": true,
	"es-ar" : true,
	"ar-sa" : true,
	"hi-in" : true,
	"ar-ae" : true
});