define(({

	'bankCodeType' : {
		"ae" : [ {
			"payeeTypId" : '2',
			"id" : 'LC',
			// "regExp" : '^[-_,A-Za-z0-9]*$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '3',
			"id" : 'HSBC',
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'BIC',
			"regExp" : '^[A-Za-z0-9]{8,12}$'
		} ],
		"in" : [{
		    "payeeTypId" : '2',
			"id" : 'IN',
			//"regExp" : '^[-_,A-Za-z0-9]*$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{0,11}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'IN',
			"regExp" : '^[A-Za-z0-9]{0,12}$'
		} ],
		"ca" : [ {
			"payeeTypId" : '2',
			"id" : 'CA',
			// "regExp" : '^[-_,A-Za-z0-9]*$'
			"regExp" : '^[0-9]{9}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'CA',
			"regExp" : '^[A-Za-z0-9]{0,12}$'
		} ],
		"at" : [ {
			"payeeTypId" : '2',
			"id" : 'AT',
			// "regExp" : '^(\\d{5})$'
			"regExp" : '^[A-Za-z0-9\\-]{2,12}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'AT',
			"regExp" : '^[A-Za-z0-9/-]{2,12}$'
		} ],
		"au" : [ {
			"payeeTypId" : '2',
			"id" : 'AU',
			// "regExp" : '^(\\d{6})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'AU',
			"regExp" : '^[A-Za-z0-9]{0,12}$'
		} ],
		"cc" : [ {
			"payeeTypId" : '2',
			"id" : 'CP',
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'BIC',
			"regExp" : '^[A-Za-z0-9]{8,12}$'
		} ],
		"es" : [ {
			"payeeTypId" : '2',
			"id" : 'ES',
			// "regExp" : '^(\\d{8,9})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'ES',
			"regExp" : '^[A-Za-z0-9/-]{2,12}$'
		} ],
		"gr" : [ {
			"payeeTypId" : '2',
			"id" : 'GR',
			// "regExp" : '^(\\d{7})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'GR',
			"regExp" : '^[A-Za-z0-9/-]{2,12}$'
		} ],
		"hk" : [ {
			"payeeTypId" : '2',
			"id" : 'HK',
			// "regExp" : '^(\\d{3})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{0,11}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'HK',
			"regExp" : '^[A-Za-z0-9/-]{2,12}$'
		} ],
		"ie" : [ {
			"payeeTypId" : '2',
			"id" : 'IE',
			// "regExp" : '^(\\d{6})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'IE',
			"regExp" : '^[A-Za-z0-9/-]{2,12}$'
		} ],
		"nz" : [ {
			"payeeTypId" : '2',
			"id" : 'NZ',
			// "regExp" : '^(\\d{6})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'NZ',
			// "regExp" : '^(\\w{8}|\\w{11})$'
			"regExp" : '^[A-Za-z0-9/-]{2,12}$'
		} ],
		"it" : [ {
			"payeeTypId" : '2',
			"id" : 'IT',
			// "regExp" : '^(\\d{10})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{0,11}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'IT',
			"regExp" : '^[A-Za-z0-9/-]{2,12}$'
		} ],
		"pl" : [ {
			"payeeTypId" : '2',
			"id" : 'PL',
			// "regExp" : '^(\\d{8})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'PL',
			"regExp" : '^[A-Za-z0-9/-]{2,12}$'
		} ],
		"pt" : [ {
			"payeeTypId" : '2',
			"id" : 'PT',
			// "regExp" : '^(\\d{8})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'PT',
			"regExp" : '^[A-Za-z0-9/-]{2,12}$'
		} ],
		"sc" : [ {
			"payeeTypId" : '2',
			"id" : 'SC',
			"regExp" : '^(\\d{8})$'
		}, {
			"payeeTypId" : '4',
			"id" : 'BIC',
			"regExp" : '^[A-Za-z0-9]{8,12}$'
		} ],
		"de" : [ {
			"payeeTypId" : '2',
			"id" : 'BL',
			// "regExp" : '^(\\d{8})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		} ],
		"us" : [ {
			"payeeTypId" : '2',
			"id" : 'CP',
			// "regExp" : '^(\\d{8})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '2',
			"id" : 'CP',
			// "regExp" : '^(\\d{8})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '2',
			"id" : 'FW',
			// "regExp" : '^(\\d{8})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'US',
			"regExp" : '^[A-Za-z0-9]{0,12}$'
		} ],
		"ru" : [ {
			"payeeTypId" : '2',
			"id" : 'RU',
			// "regExp" : '^(\\d{8})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'RU',
			"regExp" : '^[A-Za-z0-9/-]{2,12}$'
		} ],
		"sw" : [ {
			"payeeTypId" : '2',
			"id" : 'SW',
			// "regExp" : '^(\\d{8})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'BIC',
			"regExp" : '^[A-Za-z0-9]{8,12}$'
		} ],
		"gb" : [ {
			"payeeTypId" : '2',
			"id" : 'uk',
			// "regExp" : '^(\\d{8})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'GB',
			"regExp" : '^[A-Za-z0-9/-]{2,12}$' 
		} ],
		"ch" : [ {
			"payeeTypId" : '4',
			"id" : 'CH',
			"regExp" : '^[A-Za-z0-9/-]{2,12}$' 
		}],
		"bh" : [ {
			"payeeTypId" : '4',
			"id" : 'BIC',
			"regExp" : '^[A-Za-z0-9]{8,12}$'
		}],
		"bd" : [ {
			"payeeTypId" : '4',
			"id" : 'BD',
			"regExp" : '^[A-Za-z0-9]{8,12}$'
		}],
		"be" : [ {
			"payeeTypId" : '4',
			"id" : 'BIC',
			"regExp" : '^[A-Za-z0-9]{8,12}$'
		}],
		"ph" : [ {
			"payeeTypId" : '4',
			"id" : 'BIC',
			"regExp" : '^[A-Za-z0-9]{8,12}$'
		}],
		"za" : [ {
			"payeeTypId" : '4',
			"id" : 'ZA',
			"regExp" : '^[A-Za-z0-9]{0,12}$' 
		}],
		"gg" : [ {
			"payeeTypId" : '2',
			"id" : 'gg',
			// "regExp" : '^(\\d{8})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'GG',
			"regExp" : '^[A-Za-z0-9/-]{2,12}$'
		} ],
		"je" : [ {
			"payeeTypId" : '2',
			"id" : 'je',
			// "regExp" : '^(\\d{8})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'JE',
			"regExp" : '^[A-Za-z0-9/-]{2,12}$'
		} ],
		"im" : [ {
			"payeeTypId" : '2',
			"id" : 'im',
			// "regExp" : '^(\\d{8})$'
			"regExp" : '^[-_/?:().+,A-Za-z0-9]{2,10}$'
		}, {
			"payeeTypId" : '4',
			"id" : 'IM',
			"regExp" : '^[A-Za-z0-9/-]{2,12}$'
		} ]
	}
}));