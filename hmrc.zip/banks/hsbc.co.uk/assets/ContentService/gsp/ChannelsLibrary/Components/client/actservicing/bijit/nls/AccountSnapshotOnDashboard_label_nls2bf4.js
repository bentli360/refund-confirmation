define({
	root : ({
		"title" : "${productDesc}",
		"balance" : "Balance ",
		"loading" : "Loading",
		"availableLimit" : "Available Limit: ",
		"creditLimit" : "Credit Limit: ",
		"overdraftLimit" : "Overdraft:",
		"CC" : "CC",
		"DDA" : "DDA",
		"CC_prodCatCde" : "CC",
		"CHQ_prodCatCde" : "CHQ",
		"SAV_prodCatCde" : "SAV",
		"TD_prodCatCde" : "TD",
		"LOAN_prodCatCde" : "LOAN",
		"CUR_prodCatCde" : "CUR",
		"termUnit" : {
			"000001" : "Days",
			"000002" : "Months",
			"000003" : "Years"
		},
		"DD" : {
			"availBal" : "Funds available",
			"odLimitAmt" : "Overdraft"
		},
		"LOAN" : {
			"nextPymtDt" : "Next payment",
			"ovdueAmt" : "Overdue balance"
		},
		"TD" : {
			"term" : "Term",
			"mturDt" : "Maturity Date",
			"intRate" : "Interest Rate",
			"intAmt" : "Interest At Maturity"
		},
		"CC" : {
			"creditLimit" : "Credit limit",
			"availCreditAmt" : "Available credit",
			"lastStmtMinPymtAmt" : "Minimum payment"
		},
		/* THESE VALUES NEEDS TO BE CHANGED */
		"apoS" : "'s ",
		"currency" : "Currency",
		"payment" : "Payment",
		"transfer" : "Transfer",
		"viewAllTransactions" : "View All Transactions",
		"INQUIRE" : "1",
		"DOMESTIC_PAYMENT_OTHER_BANK" : "2",
		"DOMESTIC_PAYMENT_HSBC" : "3",
		"INTERNATIONAL_PAYMENT" : "4",
		"DOMESTIC_TRANSFER_TO" : "5",
		"DOMESTIC_TRANSFER_FROM" : "6",
		"INTERNATIONAL_TRANSFER_TO" : "7",
		"INTERNATIONAL_TRANSFER_FROM" : "8",
		"BILL_PAYMENT" : "9",
		// added CSS classes
		"privacy" : "privacy",
		"frmBtn" : "fr mBtn",
		"linkedBtnTransfer" : "linkButton iconButton transfer",
		"icon" : "icon",
		"linkedBtnSend" : "linkButton iconButton send",
		"paymentsId" : "_payments",
		"transferId" : "_transfer",
		"fr" : "fr",
		// Events
		"paymentsEvt" : "paymentsEvt",
		"viewAllTrns" : "viewAllTrns",
		"transferEvt" : "transferEvt",
		"hyphen" : "- ",
		"accountBalanceCSS" : "accountBalance",
		"labelCSS" : "label",
		"fundsCSS" : "funds"
	}),
	"es-ar" : true,
	"ar-sa" : true,
	"hi-in" : true,
	"en-je" : true,
	"en-gb" : true,
	"ar-ae" : true
});
