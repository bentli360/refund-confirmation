/*  AccountTypeList used in Add Beneficiary (Person) */
define(({
	"PayeeBankDetails" : [ {
		"id" : '1',
		"desckey" : '1',
		"default" : 'Y'
	}, {
		"id" : '2',
		"desckey" : '2',
		"default" : 'N'
	}, {
		"id" : '3',
		"desckey" : '3',
		"default" : 'N'
	}]
}));
