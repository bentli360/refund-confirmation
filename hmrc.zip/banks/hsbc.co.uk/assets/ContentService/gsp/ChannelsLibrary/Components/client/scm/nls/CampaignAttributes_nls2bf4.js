/**
 * NLS bundles 
 */
define({
	root : ({
			"MCS" : "Mastercard Standard Conventional",
			"MGS" : "MasterCard Titanium Conventional",
			"VCS" :"Visa Classic Conventional",
			"VGS" : "Visa Platinum Conventional",
			"MCH" : "Mastercard Standard HHA ",
			"MGH" :"Mastercard Titanium HHA",
			"VCH" :"Visa Classic HHA",
			"VGH" :"Visa Platinum HHA",
			"MGM" :"MasterCard Titanium Mouawad",
			"VGM" : "Visa Platinum Mouawad",
			"MCL" :"Mastercard Standard Ladies",
			"VCL" : "Visa Classic Ladies",
			"MGP" : "Mastercard Premier Conventional",
			"VCI" : "Visa Classic Internet",
			"VCC" : "Visa Classic Credit Card",
			"MCB" : "Mastercard Business Card",
			"VAC" : "Visa Classic",
			"VAL" : "Visa Classic",
			"VAG" : "Visa Platinum",
			"VPS" : "Visa Platinum",
			"MCT" :"Mastercard Standard",
			"MGT" : "Mastercard Titanium",
			"VCT" : "Visa Classic",
			"VGT" : "Visa Platinum",
			"VPT" : "Visa Platinum",
			"VPC" : "Visa Platinum Conventional",
			"MPA" : "Mastercard Premier",
			"VTA" : "Visa Advance Platinum",
			"VLL" : "Visa Low Limit Card"
	}),
	"ar-sa": true,
	"pt-br": true,
	"zh-cn": true,
	"zh-hk": true
});
