/*  AccountCurrencyList used in Add Beneficiary (Person) */
/*  Likely incomplete */
/* id=<value pass into BE>, desckey=<key to resolve NLS string> */
define(({
	"AccountCurrencyList" : [ {
		"id" : 'USD',
		"desckey" : 'USD',
		"default" : 'Y'
	}, {
		"id" : 'BHD',
		"desckey" : 'BHD',
		"default" : 'N'
	}, {
		"id" : 'BYR',
		"desckey" : 'BYR',
		"default" : 'N'
	}, {
		"id" : 'PHP',
		"desckey" : 'PHP',
		"default" : 'N'
	}, {
		"id" : 'INR',
		"desckey" : 'INR',
		"default" : 'N'
	}, {
		"id" : 'CAD',
		"desckey" : 'CAD',
		"default" : 'N'
	}, {
		"id" : 'AUD',
		"desckey" : 'AUD',
		"default" : 'N'
	}, {
		"id" : 'JPY',
		"desckey" : 'JPY',
		"default" : 'N'
	}, {
		"id" : 'AED',
		"desckey" : 'AED',
		"default" : 'N'
	} ]
}));
