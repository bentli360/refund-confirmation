define({

        to: "To",
        from: "From",
        toLabel: "To",
        fromLabel: "From",
        fromLabelText: "from",
        toLabelText: "to",
        divider: "-",
        fromErrorMsg:"The From date is not valid",
        toErrorMsg: "The To date is not valid",
		compareErrorMsg: "The To date must be after the From date.",
        bothDatesTheSameErrorMsg: "From and To dates can not be the same.",
        pastDateError :"Please select a date range within the last 12 months",
        futureDateError: "The date should not be in future",
		dateRangeErrorMsg: "Please enter a valid date in the format dd/mm/yyyy",
        dateRangeMissingMsg:"Date is required.",
        dateRangeMsg:"The date is out of range"

});
