define({
	root : {
		"createSOLabel" : "Create a new standing order"
	},
"en-hk": true,
	"zh-hk": true,
	"zh-cn": true,
	"en-gb" : true,
	"en-je": true,
});
