define({
	"dd" : {
		"statements" : "View / Download statements",
		"transactions" : "Download latest transactions",
		"pin" : "Request a PIN",
		"payments" : "Future dated payments",
		"info" : "View & Download Account information & Terms & conditions",
		"maturity" : "Edit maturity instructions",
		"history" : "Bill payment history",
		"amend" : "Add or amend future dated payments",
		"lost" : "Report lost or stolen card",
		"stop" : "Stop a cheque",
		"limit" : "Change account limit"
	},

	"download" : {
		"downloadAs" : "Download file as",
		"csv" : "CSV",
		"quicken" : "Quicken"
	},

	"summaryCreditCard" : {
		"creditLimit" : "Credit limit",
		"availableCredit" : "Available credit"
	},

	"summaryLoan" : {
		"nextPayment" : "Next payment",
		"overdueBalance" : "Overdue balance"
	},

	"summaryTermDeposit" : {
		"term" : "Term",
		"maturityDate" : "Maturity date"
	},

	"accountFee" : {
		"ACCOUNT_FEES_TITLE" : "Account fees",
		"ACCOUNT_FEE" : "Account fee",
		"MONTHLY_FEE" : "Monthly fee",
		"YEARLY_FIXED_FEE" : "Yearly fixed fee"
	},

	"errors" : {
		"noTransactionAvailable" : "There are no transactions available with this search",
		"beyond12months" : "You cannot search beyond 12 months of current date",
		"unrecognisedSearch" : "Un-recognised search request",
		"noSearchResults" : "No search results have been found for Alton Towers",
		"termsConditionsChanges" : "There have been some changes to the terms and conditions for this account"
	},
	"availableActions" : {
		"manage" : "Manage",
		"notifications" : "Notification setting",
		"persondetails" : "Change personal information",
		"changebanklimits" : "Online withdrawal &amp; payment limits",
		"linkglobalview" : "Add or remove a country/territory",
		"prodnewsletter" : "Newsletter subscriptions",
		"profilemanagement" : "Rename accounts",
		"requestpin" : "Request a PIN",
		"orderchequebook" : "Order chequebook",
		"stopcheque" : "Stop cheque",
		"pendinginttransaction" : "Pending international payments",
		"transactions" : "Transactions",
		"editmaturityinstructions" : "Edit maturity instructions",
		"billpaymenthistory" : "Bill payment history",
		"orderreplacement":"Order replacement card",
		"reportlostorstolencard" : "Report lost or stolen card",
		"downloadAccountInfoTnC" : "Important information, Terms & Conditions",
		"downloadlatesttransactions" : "Latest transactions",
		"statements" : "View & print statements",
		"futuredatemanagement" : "Change future-dated payments",
		"viewhsbcexpatportfolio" : "View HSBC Expat portfolio",
		"talktoanexpert" : "Talk to an expert",
		"buysellswitchhsbcfunds" : "Buy, Sell & Switch HSBC funds",
		"applyforanhsbcfund" : "Apply for an HSBC fund",
		"tariffofcharges" : "Tariff&nbsp;of&nbsp;Charges",
		"printAccountSummary" : "Print account details",
		"printTransactionSummary" : "Print transaction summary",
		"balancetransfer" : "Balance Transfer",
		"creditcardrepayment" : "Credit Card Repayment",
		"midata" : "midata",
		"optOutCreditCrdAutoLmtInc" : "Opt out of credit card auto limit increase",
		"verifiedByVisa" : "Verified by VISA"
	},
	"dialog" : {
		"opensDialog" : "Opens a dialog"
	},
	// New design manage menu labels
	"futuredatemanagement" : "Standing orders and future payments",
	"payeemanagement" : "My payees",
	"mydocuments" :"My documents",
	"newtransaction" : "Pay or transfer",
	recurAndFuture:"Recurring and future payments",
    "autopayments" : "Direct Debits",
    "paybilltransfer" : "Pay bill or transfer",
	"statementoptions" : "Statement delivery options",
	"requestpin" : "Send me my PIN",
	"loststolencard" : "Report lost or stolen card", 
	"activatecards" : "Activate card",
	"stmtsAnnSumaries" : "Statements/Annual Summaries",
	"communicationpreferences" : "Communication Preferences",
	"transactions" : "Transactions",
	"CommPref": "Communication preferences",
	"contactinfo" : "Personal & address details",
	"increasecreditlimitbusinessinitiated" : "Request a higher limit",
	"editmaturityinstructions" : "Update maturity instructions",
	"verifiedbyvisaAndMasterCard" : "Verified by VISA/Mastercard SecureCode",
	"manageMyMortgage" : "Manage my mortgage",
	"verifiedbyvisa" : "Verified by VISA",
	"downloadmiddata" : "midata download",
	"edocs" : "My documents",
	"stopcheque" : "Stop cheque",
	"pendinginttransaction" : "Pending international payments",
    "accservices" : "<strong>Account services</strong>",
    "closeacc" : "Close account",
    "querytransaction" : "Query transaction",
    "orderreplacecard" : "Replace a damaged card",
    "travelnotification" : "Notify us of travel",
	"ccbalanctrans" : "Balance transfer",
	"changeRateOnly" : "Change my rate only",
	"makeOtherChanges" : "Make other changes",
	"myRateChangeApp" : "My rate change applications",
	"mySavedApps" : "My saved applications",
	"recentMortDocs" : "Recent mortgage documents",
	"makeChanges" : "<strong>Make changes</strong>",
	"repayPersonalLn" : "Repay Personal Loan",
	"blockUnblockCards" : "Block or unblock card"
});
