define({
    root: {
        validationMessage: "Please write your message here",
        txtAreaErrorMsg: "A valid amount must be inputted.",
        txtAreaMissingMsg:"Message is required."
    },
    "es-ar" :true
});