define({
    root : ({
        "267" : {
            "title" : "Duplicate Transfer",
            "message" : "These details match another payment already set up on your account. To proceed, select Continue. To change the payment details select Cancel. ",
            "confirmMessage" : "",
            "okLabel" : "Continue",
            "cancelLabel" : "Cancel"
        },
        "269" : {
			"title" : "Duplicate payment",
            "message" : "These details match another payment already set up on your account. To proceed, select Continue. To change the payment details select Cancel. ",
            "confirmMessage" : "",
			"okLabel" : "Continue",
			"cancelLabel" : "Cancel"
        },
        "31123" : {
            "title" : "Duplicate Payment",
            "message" : "These details match another payment already set up on your account. To proceed, select Continue. To change the payment details select Cancel. ",
            "confirmMessage" : "",
            "okLabel" : "Continue",
            "cancelLabel" : "Cancel"
        },
        "H56" : {
            "title" : "Pay tomorrow",
            "message" : "The cut off time to send this payment today has passed. If you still want to make this payment it will be sent tomorrow. Select \'Confirm\' to send this payment tomorrow or Cancel.",
            "confirmMessage" : "",
            "okLabel" : "Confirm",
            "cancelLabel" : "Cancel"
        },
        "H55" : {
            "title" : "Pay tomorrow",
            "message" : "The cut off time to send this payment today has passed. If you still want to make this payment it will be sent tomorrow. Select \'Confirm\' to send this payment tomorrow or Cancel.",
            "confirmMessage" : "",
            "okLabel" : "Confirm",
            "cancelLabel" : "Cancel"
        },
        "H58" : {
            "title" : "H58",
            "message" : "We are unable to process as a faster payment. Would you like us to process using the 2 day payment cycle? (H58)",
            "confirmMessage" : "",
            "okLabel" : "Continue",
            "cancelLabel" : "Cancel"
        },
        "H59" : {
            "title" : "H59",
            "message" : "We are unable to process as a faster payment. Would you like us to process using the 2 day payment cycle? (H59)",
            "confirmMessage" : "",
            "okLabel" : "Continue",
            "cancelLabel" : "Cancel"
        },
        "H60" : {
            "title" : "H60",
            "message" : "The Beneficiary Bank is unable to receive this payment at the present time.  Would you like us to send the payment later today? (H60)",
            "confirmMessage" : "",
            "okLabel" : "Continue",
            "cancelLabel" : "Cancel"
        },
        "H63" : {
            "title" : "H63",
            "message" : "We are unable to process as a faster payment as the amount exceeds the Faster Payment daily limit.  Would you like us to process using the 2 day payment cycle? (H63)",
            "confirmMessage" : "",
            "okLabel" : "Continue",
            "cancelLabel" : "Cancel"
        },
        "H64" : {
            "title" : "H64",
            "message" : "We are unable to process as a faster payment as the amount exceeds the Faster Payment daily limit.  Would you like us to process using the 2 day payment cycle? (H64)",
            "confirmMessage" : "",
            "okLabel" : "Continue",
            "cancelLabel" : "Cancel"
        },
        "H66" : {
            "title" : "H66",
            "message" : "We are unable to process as a faster payment.  Would you like us to process using the 2 day payment cycle? (H66)",
            "confirmMessage" : "",
            "okLabel" : "Continue",
            "cancelLabel" : "Cancel"
        },
        "H67" : {
            "title" : "H67",
            "message" : "We are unable to process as a faster payment. Would you like us to process using the 2 day payment cycle? (H67)",
            "confirmMessage" : "",
            "okLabel" : "Continue",
            "cancelLabel" : "Cancel"
        },
        "H90" : {
            "title" : "H90",
            "message" : "We are unable to deal with your request. Please try again later. (H90)",
            "confirmMessage" : "",
            "okLabel" : "Continue",
            "cancelLabel" : "Cancel"
        },
        "265" : {
            "title" : "265",
            "message" :"The date you have entered is not available. The next available date is ${Param1}. Click on 'OK' to amend the date.",
            "confirmMessage" : "",
            "okLabel" : "Continue",
            "cancelLabel" : "Cancel"
        }
    }),
"zh-hk": true,
"zh-cn": true,
    "en-gb": true
});
