define({
	root : ({
		'Select' : 'Select',
		'untilFurther' : 'Until further notice',
		'date' : 'End date',
		'numPayments' : 'Number of payments',
		'gtffDate' : 'Final Payment Date',
		'gtffNumPymts' :'Number of payments'
	}),
"es-ar": true,
	"hi-in" : true,
	"en-gb" : true,
	"en-je" : true,
	"en-sa" : true,
	"en-hk" : true,
	"zh-cn" : true,
	"zh-hk" : true
});
