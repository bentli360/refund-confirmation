/*  Bank Names used in Add Beneficiary (Person) */
/*  Likely incomplete */
/* desckey=<value pass into BE>, id=<key to resolve NLS string> */
define(({
	"NameList" : [ {
		"id" : 'AUBK PHPC',
		"desckey" : 'AUBK PHPC'
	}, {
		"id" : 'ANZB PHMA',
		"desckey" : 'ANZB PHMA'
	}, {
		"id" : 'BOOO PHMD',
		"desckey" : 'BANCO DE ORO'
	}, {
		"id" : 'BABL PHMA',
		"desckey" : 'BABL PHMA'
	}, {
		"id" : 'BANS PHMA',
		"desckey" : 'BANS PHMA'
	}, {
		"id" : 'BACP PHMA',
		"desckey" : 'BACP PHMA'
	}, {
		"id" : 'CBMN PHMA',
		"desckey" : 'CBMN PHMA'
	}, {
		"id" : 'BKEW PHMA',
		"desckey" : 'BKEW PHMA'
	}, {
		"id" : 'BKEZ PHMN',
		"desckey" : 'BKEZ PHMN'
	},{
		"id" : 'CHBK PHMN',
		"desckey" : 'CHBK PHMN'
	},{
		"id" : 'CTCH PHMA',
		"desckey" : 'CTCH PHMA'
	},{
		"id" : 'CITI PHMM',
		"desckey" : 'CITI PHMM'
	},{
		"id" : 'DEUT PHMA',
		"desckey" : 'DEUT PHMA'
	},{
		"id" : 'DBTP PHMM',
		"desckey" : 'DBTP PHMM'
	},{
		"id" : 'EWBC PHMA',
		"desckey" : 'EWBC PHMA'
	},{
		"id" : 'ICBC PHMA',
		"desckey" : 'ICBC PHMA'
	},{
		"id" : 'CHAS PHMA',
		"desckey" : 'CHAS PHMA'
	},{
		"id" : 'LBPH PHMA',
		"desckey" : 'LBPH PHMA'
	},{
		"id" : 'PNBR PHMA',
		"desckey" : 'PNBR PHMA'
	},{
		"id" : 'MEAK PHMN',
		"desckey" : 'MEAK PHMN'
	},{
		"id" : 'FUJI PHMA',
		"desckey" : 'FUJI PHMA'
	},{
		"id" : 'PBCM PHML',
		"desckey" : 'PBCM PHML'
	},{
		"id" : 'PHNB PHMA',
		"desckey" : 'PHNB PHMA'
	},{
		"id" : 'PTCO PHMS',
		"desckey" : 'PTCO PHMS'
	},{
		"id" : 'RZCC PHMA',
		"desckey" : 'RZCC PHMA'
	},{
		"id" : 'SCTO PHMA',
		"desckey" : 'SCTO PHMA'
	},{
		"id" : 'CATB PHMC',
		"desckey" : 'CATB PHMC'
	},{
		"id" : 'UBOP PHML',
		"desckey" : 'UBOP PHML'
	},{
		"id" : 'UCPB PHMA',
		"desckey" : 'UCPB PHMA'
	},{
		"id" : 'ASCB PHMA',
		"desckey" : 'ASCB PHMA'
	},{
		"id" : 'PVBK PHMN',
		"desckey" : 'PVBK PHMN'
	}]
}));
