define({
	"createSOLabel" : "Create a new standing order"
});