define({
	'verifylocalRegText':'Please verify the details as soon as possible and click "Confirm" to complete the transaction before the exchange rate expires (if applicable). ',
	'localRegText': "",
	'localRegTextM2NMInt':"",
	'legalRegText': "",
	'localRegulationsConfirm' : "Immediate transfers may not leave your account straight away, so do not re-enter this transfer.<br/><br/>Please make sure your account has a sufficient available balance until the transfer has been debited.",
	'localRegulationsNow' : "By selecting \'Confirm\' you agree to accept the rate above and confirm your transfer instruction. ",
	"localRegTextFutureDated": "The HSBC Global Exchange Rate will be applied on the day and at the time the payment is made. You can get an indication of the HSBC Exchange Rate online up to 23:59 on the day before we start making the payment by: selecting the payee from \'My payees\' and inputting the payment amount and currency.",
    'exchangeRateDisclaimer':"We'll make your International Payment using the details you provide to us.  Please check they are correct before selecting 'Confirm' to avoid any unnecessary delays or charges.  It's also important to ensure there is a sufficient balance in your account on the due date.",
    'localRegulationTaxMsg20Percent' : 'The tax amount was calculated accordingly to local regulation RG(AFIP) 3583/14 (20%)',
    'localRegulationTaxMsg35Percent' : 'the tax amount was calculated accordingly to local regulation RG(AFIP) 3450 (35%)',
    'legalText':"Please check the payment details carefully. If the details are correct, please select the 'Confirm' button to make this payment. If you need to change any details, select 'Edit these details' button.",
    'legalTextUK':"Global Transfers will be subject to local laws, regulations and Terms and Conditions of the country from which the transfer originates. In order to make this transfer, personal information relating to any individuals named in your transfer instruction (and the reason for the transfer) may be provided to overseas authorities in order to comply with applicable legal obligations.",
    'imdPaymentTxt': "Select \'Confirm\' to accept the rate above (if applicable) and submit your payment instruction, once it has been confirmed it cannot be cancelled. <br/>If this payment cannot be made or is returned by the payee's bank for any reason, the payment will be reversed which may mean a different amount is credited back to your account due to exchange rate movements.",
    'futurePymntTxt':""
});
