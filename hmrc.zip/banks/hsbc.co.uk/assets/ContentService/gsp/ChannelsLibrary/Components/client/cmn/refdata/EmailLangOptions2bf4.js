/* Global Reference Data representing Email language options */
/* DD ID: 00069 */
/* id=<value pass into BE>, desckey=<key to resolve NLS string> */
define(({
	"EmailLangOptions" : [

	{
		"id" : 'en',
		"desckey" : 'ENGLISH',
		"defaultflag": 'Y'
	},
	{
		"id" : 'zh_CN',
		"desckey" : 'CHINESE',
		"defaultflag": 'N'
	},
	{
		"id" : 'zh_HK',
		"desckey" : 'TCHINESE',
		"defaultflag": 'N'
	},
	{
		"id" : 'fr',
		"desckey" : 'FRENCH',
		"defaultflag": 'N'
	},
	{
		"id" : 'id',
		"desckey" : 'INDONESIAN',
		"defaultflag": 'N'
	},
	{
		"id" : 'ja',
		"desckey" : 'JAPAENSE',
		"defaultflag": 'N'
	},
	{
		"id" : 'pt',
		"desckey" : 'PORTUGUESE',
		"defaultflag": 'N'
	},
	{
		"id" : 'es',
		"desckey" : 'SPANISH',
		"defaultflag": 'N'
	},
	{
		"id" : 'th',
		"desckey" : 'THAI',
		"defaultflag": 'N'
	}]
}));
