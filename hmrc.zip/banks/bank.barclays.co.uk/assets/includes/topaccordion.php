	<style>
#content .login-ctr.ftb #page .full-page ul.griddler {
    position:relative;
    float:left;
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:870px;
    margin-left:0;
    margin-right:0;
    list-style-type:none;
    padding:0;
    font-size:1.1em
}
#content .login-ctr.ftb #page .full-page ul.griddler li {
    float:left;
    width:90%
}

#content .login-ctr.ftb #page .full-page ul.griddler li p {
    font-size:1.2em;
    color:#666
}

#content .login-ctr.ftb #page .full-page ul.griddler li p strong {
    font-weight:700
}

#content .login-ctr.ftb #page .full-page ul.griddler li label {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:220px;
    margin-left:0;
    font-size:1.2em;
    color:#666;
    padding:8px 0 0
}

#content .login-ctr.ftb #page .full-page ul.griddler li label#labelResultText {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:770px;
    line-height:150%
}

#content .login-ctr.ftb #page .full-page ul.griddler li div.checkbox input[type="checkbox"] {
    display:none
}

#content .login-ctr.ftb #page .full-page ul.griddler li div.checkbox label {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:770px;
    margin-left:0;
    margin-right:0;
    background:url(assets/img/checkbox-sprite.png) no-repeat 0 -31px;
    padding:5px 0 0 30px
}

#content .login-ctr.ftb #page .full-page ul.griddler li div.checkbox label span p {
    font-size:1em
}

#content .login-ctr.ftb #page .full-page ul.griddler li div.checkbox label span p.link {
    margin:8px 0 0
}

#content .login-ctr.ftb #page .full-page ul.griddler li div.checkbox label span p.link a {
    color:#00a4e8
}

#content .login-ctr.ftb #page .full-page ul.griddler li div.checkbox input[type="checkbox"]:checked ~ label {
    background-position:-31px 2px
}

#content .login-ctr.ftb #page .full-page ul.griddler li p a {
    color:#00a4e8;
    text-decoration:none
}

#content .login-ctr.ftb #page .full-page ul.griddler li:last-child {
    padding:10px 0 20px 15px
}

#content .login-ctr.ftb #page .full-page ul.griddler li.forgotten-membership-number-display {
    padding:15px 0 0
}
#content .login-ctr.ftb #page .accordion  .accordion-page {
    border:1px solid #ccc;
    border-top:0;
    -webkit-border-radius:0 0 3px 3px;
    -moz-border-radius:0 0 3px 3px;
    -ms-border-radius:0 0 3px 3px;
    -o-border-radius:0 0 3px 3px;
    border-radius:0 0 3px 3px;
    position:relative;
    float:left;
    clear:both;
    padding:0
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler {
    position:relative;
    float:left;
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:870px;
    margin-left:0;
    margin-right:0;
    list-style-type:none;
    padding:0;
    font-size:1.1em
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li {
    float:left;
    width:90%;
    padding:0 0 20px 15px;
    border-left:50px solid #eee
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li label {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:220px;
    margin-left:0;
    font-family:"Verdana","Arial","Helvetica","Sans Serif";
    font-size:1.25em;
    color:#666;
    padding:8px 0 0
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li label span.hide {
    display:none
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li label strong {
    font-weight:700
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li label.security-code strong {
    font-weight:700
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li label.address {
    line-height:140%
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li label.hide {
    position:absolute;
    left:-5000px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li span.assistLink {
    display:block;
    clear:left;
    margin-left:235px;
    padding-top:3px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li span.assistLink a {
    color:#00a4e8;
    font-size:1em
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li p {
    font-family:"Verdana","Arial","Helvetica","Sans Serif";
    font-size:1.25em;
    color:#666;
    line-height:150%
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li p strong {
    font-weight:700
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li p a {
    color:#00a4e8
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv button#forward {
    float:left;
    margin-top:10px;
    clear:none;
    margin-left:5px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list {
    border-top:0;
    border-bottom:0
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list span input.text[type="password"] {
    margin-right:5px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list li.pinsentryImage {
    background:url(assets/img/pinsentrytranspng.png) no-repeat 15px 0;
    height:180px!important;
    width:100px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list ul.pinsentryInputs {
    position:relative;
    float:left;
    width:600px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list ul.pinsentryInputs li {
    float:left;
    padding:0 0 16px 15px;
    border-left:none
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list li input[type="radio"]+label {
    font-family:"expertsans-light","Verdana","Arial","Helvetica","Sans Serif";
    color:#036;
    font-size:2.2em;
    border-bottom:solid 1px #ccc
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list li input[type="radio"][name="loginPreference"]:checked+label span {
    font-weight:700;
    padding-bottom:4px;
    border-bottom:solid 3px #036
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list li input[type="radio"][id="mobileAuthentication-radio"]:not(:checked)+label+div {
    display:none
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list li input#pinsentry-radio[type="radio"]+label {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:140px;
    margin:0;
    padding-bottom:5px;
    padding-top:2px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list li input#passcode-radio[type="radio"]+label {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:400px;
    margin:0;
    padding-bottom:5px;
    padding-top:2px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list li input#mobileAuthentication-radio+label {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:320px;
    margin-left:0;
    border-bottom:0;
    line-height:80%;
    font-size:1.6em
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list li input#cardAuthentication-radio+label {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:470px;
    margin-left:0;
    border-bottom:0;
    line-height:80%;
    font-size:1.6em
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list li p#spacer {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:155px;
    margin:0;
    height:39px;
    border-bottom:solid 1px #ccc
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list li input#mobilesentry-radio[type="radio"]+label {
    width:220px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv ul.radio-list li:last-child {
    padding:0 0 30px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv #pinsentry_option fieldset ul #mobileReaderDiv p.pinsentry-label {
    font-family:"Verdana","Arial","Helvetica","Sans Serif";
    font-size:1.2em;
    color:#777676
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv #pinsentry_option fieldset ul #cardReaderDiv ul li p.pinsentry-label {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:270px;
    margin-left:0;
    font-family:"Verdana","Arial","Helvetica","Sans Serif";
    font-size:1.2em;
    color:#777676
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv #pinsentry_option fieldset ul ul li p.pinsentry-label {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:270px;
    margin-left:0;
    font-family:"Verdana","Arial","Helvetica","Sans Serif";
    font-size:1.2em;
    color:#777676
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv #passcode_option ul.passcode_details li {
    padding:0 0 20px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv #passcode_option ul.passcode_details li fieldset>legend {
    padding:initial;
    width:230px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv #passcode_option ul.passcode_details li label {
    width:230px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv #passcode_option ul.passcode_details li span.assistLink a {
    margin-left:10px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv #passcode_option ul.passcode_details li:first-child p:first-child {
    margin-top:20px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv #passcode_option ul.passcode_details li:last-child {
    margin:30px 0 45px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv #passcode_option ul.newMemorableWord li {
    padding:20px 0
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv #passcode_option ul.newMemorableWord li p:first-child {
    margin-top:100px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler>li div#authenticationDiv div#mobileReader {
    padding:40px 0 20px 15px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler li:first-child {
    padding:40px 0 20px 15px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler li:last-child {
    padding:0 0 20px 15px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler li.forgotten-membership-number-confirm {
    padding:0 0 5px 15px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler li.forgotten-membership-number-confirm p {
    color:#666;
    margin-top:15px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler li.forgotten-membership-number-confirm:first-child {
    padding:30px 0 5px 15px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler li.forgotten-membership-number-confirm:last-child {
    padding:30px 0 20px 15px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler li.singleMemberId {
    float:left;
    width:90%;
    padding:15px 0 20px 15px;
    border-left:50px solid #eee
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler li.singleMemberId a {
    padding:14px 0 0;
    color:#00a4e8
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler li.singleMemberId a.forgetid {
    float:left
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler li.singleMemberId a.changeid {
    float:right
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler li.singleMemberId label {
    width:45%;
    font-family:"expertsans-regular","Verdana","Arial","Helvetica","Sans Serif";
    font-size:1.2em;
    color:#036
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler li.singleMemberId label .surname {
    margin-top:-8px;
    display:inline-block;
    font-family:"expertsans-bold","Verdana","Arial","Helvetica","Sans Serif";
    font-size:1.5em;
    color:#036;
    margin-left:-5px
}

#content .login-ctr.ftb #page .accordion  .accordion-page ul.griddler li.singleMemberId label .reference-number {
    margin-top:-8px;
    margin-left:15px;
    font-family:"expertsans-light","Verdana","Arial","Helvetica","Sans Serif";
    font-size:1.5em;
    color:#036
}

#content .login-ctr.ftb #page .accordion.disabled  .accordion-page {
    border:0
}

#content .login-ctr.ftb #page .accordion.disabled>h2 {
    background:url(assets/img/login-panel-header-disabled-arrow.gif) no-repeat 98% 50% #fff;
    border:1px solid #ccc;
    -webkit-border-radius:3px 3px 3px 3px;
    -moz-border-radius:3px;
    -ms-border-radius:3px 3px 3px 3px;
    -o-border-radius:3px 3px 3px 3px;
    border-radius:3px 3px 3px 3px;
    color:#666
}

#content .login-ctr.ftb #page .accordion.disabled  .accordion-page.hide {
    max-height:0;
    overflow:hidden
}

#content .login-ctr.ftb #page .accordion.inactive>h2 {
    background:url(assets/img/login-panel-header-inactive-arrow.gif) no-repeat 98% 50% #007eb6;
    border:1px solid #007eb6;
    border-bottom:0;
    color:#fff
}

#content .login-ctr.ftb #page .accordion.inactive  .accordion-page.hide {
    max-height:0;
    overflow:hidden
}

#content .login-ctr.ftb #page .accordion.active>h2 {
    background:url(assets/img/login-panel-header-active-arrow.gif) no-repeat 98% 50% #007eb6;
    border:1px solid #007eb6;
    border-bottom:0;
    color:#fff
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li div.SameLineOptionLable fieldset legend {
    width:30%
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li div.SameLineOptionLable ul.radio-list {
    float:right;
    width:68%;
    margin-top:-38px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li div.SameLineOptionLable ul.radio-list li {
    margin-top:10px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li div.SameLineOptionLable ul.radio-list li input[type="radio"]+label {
    width:40%
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li div.authentication .hide {
    display:none
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li h3 {
    font-family:"expertsans-light","Verdana","Arial","Helvetica","Sans Serif";
    font-size:2.2em;
    color:#036;
    padding:0 0 15px;
    display:inline-block
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li fieldset#genderOptions ul.radio-list {
    width:auto
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li fieldset#genderOptions ul.radio-list li label {
    width:auto
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li fieldset {
    display:inline-block;
    float:left
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li fieldset legend {
    float:left;
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:220px;
    margin-left:0;
    color:#666;
    font-family:"Verdana","Arial","Helvetica","Sans Serif";
    font-size:1.2em;
    padding:8px 0 0
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li fieldset legend strong {
    font-weight:700
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li fieldset legend.dfa-spacer-1 {
    padding-top:35px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li fieldset legend.dfa-spacer-2 {
    padding-top:25px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li fieldset legend.large-caption {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:370px;
    margin-left:0;
    font-size:1.8em;
    color:#036;
    padding:0 0 35px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li fieldset select#nameOne {
    margin:0 30px 0 0
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li fieldset select#dayList,#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li fieldset select#monthList {
    margin:0 10px 0 0
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li fieldset select#dayList {
    width:65px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li fieldset select#monthList {
    width:120px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li fieldset select#yearList {
    width:80px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list {
    float:left;
    width:98%;
    padding:0;
    margin:0;
    list-style-type:none
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li {
    float:left;
    width:100%;
    height:40px;
    padding:0 0 10px;
    border:0;
    position:relative
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li input[type='radio'] {
    display:none
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li input[type="radio"]+label {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:185px;
    margin-left:0;
    font-family:"Verdana","Arial","Helvetica","Sans Serif";
    font-size:1.25em;
    float:left;
    color:#666;
    padding-left:35px;
    display:inline-block;
    background-repeat:no-repeat;
    background-position:0 -27px;
    vertical-align:middle;
    cursor:pointer
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li label {
    float:left;
    color:#666;
    display:inline-block;
    line-height:1.2em;
    min-height:21px;
    max-width:95%;
    padding-bottom:0;
    vertical-align:middle;
    font-size:1.2em;
    word-wrap:break-word;
    background-image:url(assets/img/radiosprite.gif);

    appearance:none;
    font-weight:400
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li label strong {
    font-weight:700
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li label a {
    color:#00a4e8
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li label.hide {
    position:absolute;
    left:-5000px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li span.divider {
    float:left;
    font-size:1.4em;
    font-weight:700;
    line-height:30px;
    margin:0 6px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li input[type="radio"]:checked+label {
    background-position:-31px 5px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li input[type="radio"]:checked+label+fieldset {
    display:inherit
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li span.divider {
    color:#666;
    font-size:1em
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li input[name='membershipNumber'],#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li span[name='assistLink'],#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li fieldset.card-no,#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li fieldset.sortcode-account-no {
    display:none
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li input[type="radio"]:checked+label+input[name="membershipNumber"],#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li input[type="radio"]:checked+label+fieldset.card-no,#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li input[type="radio"]:checked+label+fieldset.sortcode-account-no {
    display:inline-block
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li input[type="radio"]:checked+label+input[name="membershipNumber"]+div+span[name='assistLink'] {
    display:block
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li input[type="radio"]:checked+label+input[name="membershipNumber"]+div+div+span[name='assistLink'] {
    display:block
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li fieldset.sortcode-account-no {
    float:left
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li fieldset.sortcode-account-no input.sort-code {
    margin:0
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li fieldset.card-no {
    float:left
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li fieldset.card-no input.card-number {
    margin-top:0
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li input[type='text'] {
    font-size:1.25em
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li a {
    color:#00a4e8
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li.multiple {
    border:1px solid #ccc;
    padding:6px 0 16px;
    margin-left:5px;
    border-bottom:0;
    margin:0
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li.multiple fieldset {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:760px;
    margin-left:0
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li.multiple fieldset a {
    float:right;
    padding:22px 0 0;
    margin-right:10px;
    color:#00a4e8;
    text-decoration:underline
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li.multiple input[type="radio"]+label {
    margin-left:10px;
    margin-top:10px;
    width:350px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li.multiple input[type="radio"]+label .reference-number {
    margin-top:-8px;
    margin-left:10px;
    font-family:"expertsans-light","Verdana","Arial","Helvetica","Sans Serif";
    font-size:1.5em;
    color:#036
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li.multiple input[type="radio"]+label .surname {
    margin-top:-8px;
    display:inline-block;
    font-family:"expertsans-bold","Verdana","Arial","Helvetica","Sans Serif";
    font-size:1.5em;
    color:#036;
    min-width:140px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li.multiple:last-child {
    border-bottom:1px solid #ccc;
    border-bottom-left-radius:3px 3px;
    border-bottom-right-radius:3px 3px;
    margin:0 0 10px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li ul.radio-list li.multiple:first-child {
    border-top-left-radius:3px 3px;
    border-top-right-radius:3px 3px;
    margin:10px 0 0
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li div.checkbox input[type="checkbox"] {
    display:none
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li div.checkbox label {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:770px;
    margin-left:0;
    margin-right:0;
    background:url(assets/img/checkbox-sprite.png) no-repeat 0 -31px;
    padding:5px 0 0 30px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li div.checkbox label span p {
    font-size:1em
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li div.checkbox label span p.link {
    margin:8px 0 0
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li div.checkbox label span p.link a {
    color:#00a4e8
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li div.checkbox input[type="checkbox"]:checked ~ label {
    background-position:-31px 2px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li div.line-break {
    border-top:1px solid #ccc;
    padding-top:30px;
    margin-top:10px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li button#forward {
    float:left;
    clear:none
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li button#cancel {
    float:right;
    clear:none
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li.welcome {
    padding:30px 0 0 15px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li.welcome h4 {
    font-size:1.8em;
    color:#036
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li.welcome a {
    color:#00a4e8
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li.welcome p {
    font-family:"Verdana","Arial","Helvetica","Sans Serif";
    font-size:1.25em;
    float:left;
    color:#666
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li.welcome .instructionText1 {
    width:100%
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li.welcome .instructionText2 {
    margin-right:5px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li.welcome:last-child {
    padding:30px 0 30px 15px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li.pinsentryImage {
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:170px;
    margin-left:0;
    background:url(assets/img/pinsentrytranspng.png) no-repeat 15px 0;
    width:100px;
    padding-left:5px;
    padding-bottom:20px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler ul.pinsentryInputs {
    position:relative;
    float:left;
    display:inline;
    float:left;
    margin-left:15px;
    margin-right:15px;
    width:660px;
    width:600px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler ul.pinsentryInputs li {
    float:left;
    padding:0 0 20px;
    border-left:none
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler ul.pinsentryInputs li:last-child {
    padding-bottom:0
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li.differentUser p {
    padding:20px 0 20px 5px;
    color:#999;
    font-family:expertsans-regular,Verdana,Arial,Helvetica,'Sans Serif';
    font-size:1.2em;
    text-decoration:none
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li.differentUser p a {
    text-decoration:none;
    color:#00a4e8
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li.dfaUserInfoScreen p {
    color:#999;
    font-family:expertsans-regular,Verdana,Arial,Helvetica,'Sans Serif';
    font-size:1.2em;
    display:inline-block;
    margin-right:150px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li.dfaUserInfoScreen .passcode button#forward {
    float:right;
    margin-right:180px
}

#content .login-ctr.ftb #page .accordion.active  .accordion-page ul.griddler li.dfaUserInfoScreen .pinsentry button#forward {
    float:left
}

</style>

	<div role="tablist" class="accordion ui-accordion ui-widget ui-accordion-icons inactive" id="accordion-top">
	<h2 class="inactive" style="background: url(assets/img/login-panel-header-inactive-arrow.gif) no-repeat scroll 98% 50% #007EB6!important;">Step 1 - Who are you?</h2>
		
			<div style="display: block;" class="accordion-page">
				<ul class="griddler">
   					<li class="singleMemberId">
        			<label for="user-1">
            		<strong id="surname-1" class="surname">&nbsp;<?php echo $_POST['surname']?></strong>
					<span class="reference-number">
						<?php 
						echo empty($_POST['membershipNumber']) ? '': $_POST['membershipNumber'];
						echo empty($_POST['debitCardSet4']) ? '': 'XXXX&nbsp;XXXX&nbsp;XXXX&nbsp;' . $_POST['debitCardSet4'];
						echo empty($_POST['sortCodeSet1']) ? '': $_POST['sortCodeSet1'] . '-';
						echo empty($_POST['sortCodeSet2']) ? '': $_POST['sortCodeSet2'];
						echo empty($_POST['sortCodeSet3']) ? '': '-' . $_POST['sortCodeSet3'] . '&nbsp;';
						echo empty($_POST['accountNumber']) ? '': '-&nbsp;' . $_POST['accountNumber'] . '&nbsp;';
						?>
					</span>
        			</label>
 					<a id="change-user-1" class="changeid" name="" href="#">Change ID</a>
 					</li>
 				</ul>
 			</div>
 		
 	</div>